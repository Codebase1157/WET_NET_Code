#!/usr/bin/env python3
"""Measure the efficiency columns of Tables III, V, VI, VII and VIII.

Everything printed here is measured from the instantiated model.  Accuracy columns are NOT
produced by this script -- they require training on the real datasets.
"""
import argparse, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from wetnet import WETNet, WETNetConfig
from wetnet.complexity import count_macs, measure_latency

ap = argparse.ArgumentParser()
ap.add_argument("--size", type=int, default=256)
ap.add_argument("--device", default="cpu")
ap.add_argument("--latency-runs", type=int, default=5)
ap.add_argument("--out", default="results/complexity.json")
a = ap.parse_args()

SPECS = {
    "Table III - encoder": [
        ("LRRE (ours)",           dict(encoder="lrre")),
        ("ResNet-18",             dict(encoder="resnet18")),
        ("ResNet-34",             dict(encoder="resnet34")),
        ("MobileNetV3-small",     dict(encoder="mobilenetv3_small")),
    ],
    "Table V - bridge": [
        ("WEB (ours)",            dict(bridge="web")),
        ("PDCP",                  dict(bridge="pdcp")),
        ("ASPP",                  dict(bridge="aspp")),
        ("SPP",                   dict(bridge="spp")),
        ("DoubleConv",            dict(bridge="doubleconv")),
    ],
    "Table VI - fusion rule": [
        ("(a) uniform",           dict(fusion="uniform")),
        ("(b) static gate",       dict(fusion="static")),
        ("(c) SE gate",           dict(fusion="se")),
        ("(d) evidential (ours)", dict(fusion="evidential")),
    ],
    "Table VII - wavelet basis": [
        ("db2  (L=2)",            dict(wavelet="db2", n_stages=2)),
        ("db5  (L=2, ours)",      dict(wavelet="db5", n_stages=5)),
        ("db7  (L=2)",            dict(wavelet="db7", n_stages=7)),
        ("db5  (L=1)",            dict(wavelet="db5", n_stages=5, levels=1)),
        ("db5  (L=3)",            dict(wavelet="db5", n_stages=5, levels=3)),
    ],
    "Table IV - modules": [
        ("full WET-Net",          dict()),
        ("no TAR",                dict(use_tar=False)),
        ("no WEB (DoubleConv)",   dict(bridge="doubleconv")),
        ("no WEB, no TAR",        dict(bridge="doubleconv", use_tar=False)),
    ],
}

results = {}
for table, rows in SPECS.items():
    results[table] = []
    for name, kw in rows:
        m = WETNet(WETNetConfig(**{**dict(decoder_out=24, tar_hidden=24, tar_stride=4), **kw}))
        rep = m.parameter_report()
        macs = count_macs(m, (1, 3, a.size, a.size), a.device)
        lat = measure_latency(m, (1, 3, a.size, a.size), a.device, warmup=1, runs=a.latency_runs)
        results[table].append({
            "variant": name,
            "encoder_params_M": round(rep["encoder_params"] / 1e6, 4),
            "total_params_M": round(rep["total_params"] / 1e6, 4),
            "gflops": round(macs / 1e9, 4),
            "cpu_latency_ms": round(lat, 2),
        })
        print(f"{table:28s} {name:24s} enc {rep['encoder_params']/1e6:7.4f}M "
              f"tot {rep['total_params']/1e6:7.4f}M  {macs/1e9:7.4f} GFLOPs  {lat:8.1f} ms")

Path(a.out).parent.mkdir(parents=True, exist_ok=True)
with open(a.out, "w") as fh:
    json.dump({"input_size": a.size, "device": a.device, "tables": results}, fh, indent=2)
print("wrote", a.out)
