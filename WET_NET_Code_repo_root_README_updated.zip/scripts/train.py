#!/usr/bin/env python3
"""Train WET-Net.  Every table in the paper is produced by this one entry point.

    python scripts/train.py --config configs/isic2018.yaml
    python scripts/train.py --config configs/isic2018.yaml --fusion se       # Table VI row (c)
    python scripts/train.py --config configs/isic2018.yaml --encoder resnet18  # Table III
    python scripts/train.py --config configs/isic2018.yaml --bridge pdcp     # Table V
"""
import argparse, json, os, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch.utils.data import DataLoader

from wetnet import WETNet, WETNetConfig
from wetnet.data import SkinLesionDataset, SyntheticLesions
from wetnet.losses import LossWeights, WETNetLoss
from wetnet.metrics import evaluate


def load_cfg(path):
    if not path:
        return {}
    import yaml
    with open(path) as fh:
        return yaml.safe_load(fh) or {}


def build_loaders(c):
    if c.get("synthetic"):
        tr = SyntheticLesions(n=c.get("n_train", 64), size=c.get("size", 128), seed=0)
        te = SyntheticLesions(n=c.get("n_test", 16), size=c.get("size", 128), seed=999)
    else:
        tr = SkinLesionDataset(c["train_images"], c["train_masks"], c.get("train_index"),
                               c.get("size", 256), augment=True)
        te = SkinLesionDataset(c["test_images"], c["test_masks"], c.get("test_index"),
                               c.get("size", 256), augment=False)
    bs = c.get("batch_size", 8)
    return (DataLoader(tr, bs, shuffle=True, num_workers=c.get("workers", 2), drop_last=False),
            DataLoader(te, bs, shuffle=False, num_workers=c.get("workers", 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config")
    ap.add_argument("--out", default="runs/wetnet")
    for k in ("encoder", "bridge", "fusion", "wavelet", "device"):
        ap.add_argument(f"--{k}")
    ap.add_argument("--levels", type=int)
    ap.add_argument("--epochs", type=int)
    ap.add_argument("--lambda-topo", type=float)
    ap.add_argument("--no-tar", action="store_true")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    c = load_cfg(a.config)
    for k in ("encoder", "bridge", "fusion", "wavelet", "levels", "epochs", "device"):
        if getattr(a, k, None) is not None:
            c[k] = getattr(a, k)
    if a.no_tar:
        c["use_tar"] = False
    if a.lambda_topo is not None:
        c["lambda_topo"] = a.lambda_topo

    torch.manual_seed(a.seed); np.random.seed(a.seed)
    dev = c.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    mk = {k: c[k] for k in ("encoder", "bridge", "fusion", "wavelet", "levels", "use_tar",
                            "widths", "decoder_out", "tar_hidden", "tar_stride",
                            "blocks_per_stage") if k in c}
    model = WETNet(WETNetConfig(**mk)).to(dev)
    crit = WETNetLoss(LossWeights(c.get("lambda_bce", 1.0), c.get("lambda_dice", 1.0),
                                  c.get("lambda_ev", 0.1), c.get("lambda_topo", 0.1)),
                      topo_size=c.get("topo_size", 64), topo_every=c.get("topo_every", 1))
    opt = torch.optim.AdamW(model.parameters(), lr=c.get("lr", 1e-4),
                            weight_decay=c.get("weight_decay", 1e-4))
    epochs = c.get("epochs", 300)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=c.get("lr_min", 1e-6))
    tr, te = build_loaders(c)

    print(json.dumps({"config": c, "params": model.parameter_report()}, indent=2, default=str))
    history, best = [], -1.0
    for ep in range(epochs):
        model.train(); agg, t0 = {}, time.time()
        for x, y in tr:
            x, y = x.to(dev), y.to(dev)
            opt.zero_grad()
            parts = crit(model(x), y)
            parts["loss"].backward()
            opt.step()
            for k, v in parts.items():
                agg[k] = agg.get(k, 0.0) + float(v)
        sched.step()
        row = {"epoch": ep, "sec": round(time.time() - t0, 1),
               **{k: round(v / max(len(tr), 1), 5) for k, v in agg.items()}}

        if (ep + 1) % c.get("eval_every", 10) == 0 or ep == epochs - 1:
            model.eval(); P, T, PR = [], [], []
            with torch.no_grad():
                for x, y in te:
                    pr = torch.sigmoid(model(x.to(dev))["logits"]).cpu().numpy()[:, 0]
                    PR += list(pr); P += list((pr > 0.5).astype(np.uint8))
                    T += list(y.numpy()[:, 0].astype(np.uint8))
            m = evaluate(P, T, PR)
            row.update({k: round(v, 5) for k, v in m.items()})
            if m["miou"] > best:
                best = m["miou"]
                torch.save({"model": model.state_dict(), "cfg": mk, "metrics": m},
                           out / "best.pt")
        history.append(row); print(json.dumps(row))
        with open(out / "history.json", "w") as fh:
            json.dump(history, fh, indent=1)
    print(f"best mIoU {100*best:.2f}%")


if __name__ == "__main__":
    main()
