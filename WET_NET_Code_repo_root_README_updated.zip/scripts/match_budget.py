#!/usr/bin/env python3
"""Search configurations for a target (parameters, GFLOPs) pair.

Written because the architecture as described in the manuscript does not reproduce the
reported 0.312 M / 0.184 GFLOPs.  Run this once the intended configuration is known, or use it
to find out whether the reported pair is attainable at all.
"""
import argparse, itertools, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from wetnet import WETNet, WETNetConfig
from wetnet.complexity import count_macs

ap = argparse.ArgumentParser()
ap.add_argument("--target-params", type=float, default=0.312)
ap.add_argument("--target-gflops", type=float, default=0.184)
ap.add_argument("--top", type=int, default=12)
ap.add_argument("--out", default="results/budget_search.json")
a = ap.parse_args()

WIDTHS = [(16, 32, 64, 96), (16, 32, 96, 160), (16, 32, 64, 256), (16, 48, 96, 192),
          (24, 48, 96, 192), (16, 32, 128, 256), (32, 64, 128, 192), (16, 32, 64, 384),
          (16, 32, 96, 320), (24, 48, 96, 128)]
rows = []
for w, ts, bps, dout, th in itertools.product(WIDTHS, (2, 4, 8), (1, 2, 3), (16, 24), (16, 24)):
    cfg = WETNetConfig(widths=w, tar_stride=ts, blocks_per_stage=bps,
                       decoder_out=dout, tar_hidden=th)
    m = WETNet(cfg)
    p = m.parameter_report()["total_params"] / 1e6
    g = count_macs(m) / 1e9
    err = abs(p - a.target_params) / a.target_params + abs(g - a.target_gflops) / a.target_gflops
    rows.append({"widths": list(w), "tar_stride": ts, "blocks_per_stage": bps,
                 "decoder_out": dout, "tar_hidden": th,
                 "params_M": round(p, 4), "gflops": round(g, 4), "rel_err": round(err, 4)})

rows.sort(key=lambda r: r["rel_err"])
Path("results").mkdir(exist_ok=True)
with open(a.out, "w") as fh:
    json.dump({"target": {"params_M": a.target_params, "gflops": a.target_gflops},
               "n_configs": len(rows), "best": rows[:a.top]}, fh, indent=2)
print(f"{'widths':24s}{'ts':>3}{'bps':>4}{'dout':>5}{'th':>4}  params(M)  GFLOPs   rel.err")
for r in rows[:a.top]:
    print(f"{str(tuple(r['widths'])):24s}{r['tar_stride']:>3}{r['blocks_per_stage']:>4}"
          f"{r['decoder_out']:>5}{r['tar_hidden']:>4}  {r['params_M']:.4f}    "
          f"{r['gflops']:.4f}   {r['rel_err']:.3f}")
print(f"\nbest relative error {rows[0]['rel_err']:.3f}; "
      f"a value near 0 would mean the reported pair is attainable.")
