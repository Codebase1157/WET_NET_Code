#!/usr/bin/env python3
"""Evaluate a checkpoint and print the metric row in the manuscript's format."""
import argparse, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np, torch
from torch.utils.data import DataLoader

from wetnet import WETNet, WETNetConfig
from wetnet.data import SkinLesionDataset
from wetnet.metrics import evaluate, format_row

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", required=True)
ap.add_argument("--images", required=True)
ap.add_argument("--masks", required=True)
ap.add_argument("--index")
ap.add_argument("--size", type=int, default=256)
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
a = ap.parse_args()

ck = torch.load(a.ckpt, map_location="cpu")
model = WETNet(WETNetConfig(**ck.get("cfg", {})))
model.load_state_dict(ck["model"]); model.to(a.device).eval()

ds = SkinLesionDataset(a.images, a.masks, a.index, a.size, augment=False)
P, T, PR = [], [], []
with torch.no_grad():
    for x, y in DataLoader(ds, 8):
        pr = torch.sigmoid(model(x.to(a.device))["logits"]).cpu().numpy()[:, 0]
        PR += list(pr); P += list((pr > 0.5).astype(np.uint8)); T += list(y.numpy()[:, 0].astype(np.uint8))
m = evaluate(P, T, PR)
print(json.dumps(format_row(m), indent=2))
