#!/usr/bin/env python3
"""Machine-check the mathematical claims the revised manuscript makes.

Each check corresponds to a specific sentence in the paper or a specific reviewer comment, so
that a reader can confirm the claim rather than take it on trust.  Writes results/verification.json.
"""
import json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch

from wetnet.layers.dtcwt import BAND_NAMES, DualTreeDWT2D
from wetnet.layers.persistence import persistence_pairs
from wetnet.metrics import dice_confusion, dice_set, iou_lesion, iou_macro

torch.manual_seed(0)
R = {}

# -- Section III-C (P1): losslessness -------------------------------------------------
dt = DualTreeDWT2D(levels=2)
x = torch.randn(2, 8, 16, 16)
R["P1_perfect_reconstruction_max_abs_err"] = float((dt.inverse(*dt(x)) - x).abs().max())

# -- Section III-C (P1) must survive training ------------------------------------------
with torch.no_grad():
    for p in dt.parameters():
        p.add_(torch.randn_like(p))                     # arbitrary, non-wavelet angles
R["P1_after_random_parameter_perturbation"] = float((dt.inverse(*dt(x)) - x).abs().max())

# -- Section III-C (P2): identity representability -------------------------------------
dt2 = DualTreeDWT2D(levels=2)
pa, pb = dt2(x)
w = torch.full((2, len(BAND_NAMES)), 0.25)
R["P2_uniform_weights_vs_quarter_input_max_abs_err"] = float(
    (dt2.inverse(*dt2.apply_weights(pa, pb, w)) - 0.25 * x).abs().max())

# -- Section III-C: D_w is invertible for strictly positive weights --------------------
w = torch.tensor([[0.70, 0.10, 0.15, 0.05], [0.25, 0.25, 0.25, 0.25]])
qa, qb = dt2.apply_weights(pa, pb, w)
ra, rb = dt2.apply_weights(qa, qb, 1.0 / w)
R["Dw_invertible_roundtrip_max_abs_err"] = float((dt2.inverse(ra, rb) - x).abs().max())

# -- Section III-B: depthwise-separable saving factor ----------------------------------
c_in, c_out = 96, 96
sep = 9 * c_in + c_in * c_out
full = 9 * c_in * c_out
R["separable_cost_ratio"] = round(sep / full, 5)
R["separable_saving_factor_at_Cout_96"] = round(full / sep, 3)
R["separable_ratio_formula_1_over_Cout_plus_1_over_9"] = round(1 / c_out + 1 / 9, 5)

# -- Section IV-C (Reviewer #4 comment 6): Dice identities ------------------------------
rng = np.random.default_rng(0)
d_err, id_err, macro_gap = [], [], []
for _ in range(200):
    a = rng.random((32, 32)) > 0.5
    b = rng.random((32, 32)) > 0.45
    d_err.append(abs(dice_confusion(a, b) - dice_set(a, b)))
    i = iou_lesion(a, b)
    id_err.append(abs(dice_confusion(a, b) - 2 * i / (1 + i)))
    macro_gap.append(abs(iou_lesion(a, b) - iou_macro(a, b)))
R["dice_confusion_vs_set_form_max_abs_err"] = float(np.max(d_err))
R["dice_equals_2IoU_over_1plusIoU_max_abs_err"] = float(np.max(id_err))
R["mean_gap_between_lesion_IoU_and_macro_IoU"] = round(float(np.mean(macro_gap)), 4)

# -- Section IV-D: the reported Dice/mIoU columns are consistent -------------------------
paper = {"ISIC2018": (0.8047, 0.8940), "ISIC2017": (0.7918, 0.8847),
         "HAM10000": (0.8975, 0.9472), "PH2": (0.8948, 0.9447)}
R["dice_from_reported_miou_residual_pp"] = {
    k: round(100 * (d - 2 * i / (1 + i)), 3) for k, (i, d) in paper.items()}

# -- Section III-D: topology detection ---------------------------------------------------
def disc(s, cy, cx, r):
    y, xx = np.mgrid[0:s, 0:s]
    return ((y - cy) ** 2 + (xx - cx) ** 2 < r * r).astype(np.float64)

clean = np.clip(disc(64, 32, 32, 15) * .9 + .05, 0, 1)
sat = np.clip(clean + disc(64, 10, 10, 4) * .7, 0, 1)
ann = np.clip((disc(64, 32, 32, 18) - disc(64, 32, 32, 8)) * .9 + .05, 0, 1)
R["persistence_finite_pairs"] = {
    name: {"H0": len(h0), "H1": len(h1)}
    for name, (h0, h1) in (("one_blob", persistence_pairs(clean)),
                            ("blob_plus_satellite", persistence_pairs(sat)),
                            ("annulus_with_hole", persistence_pairs(ann)))}

Path("results").mkdir(exist_ok=True)
with open("results/verification.json", "w") as fh:
    json.dump(R, fh, indent=2)
print(json.dumps(R, indent=2))
