#!/usr/bin/env python3
"""End-to-end smoke test on synthetic lesions, with an A/B on the topological loss.

WHAT THIS IS: proof that the pipeline trains, that gradients reach every module, and that
the persistence loss removes exactly the artefacts it is designed to remove (spurious
connected components and interior holes).

WHAT THIS IS NOT: a benchmark.  The data are synthetic blobs, not dermoscopy.  No number
produced here belongs in Table II or Table VIII of the paper.  Accuracy figures for the four
public datasets must come from scripts/train.py run on the real data.
"""
import argparse, json, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import torch
from torch.utils.data import DataLoader

from wetnet import WETNet, WETNetConfig
from wetnet.data import SyntheticLesions
from wetnet.losses import LossWeights, WETNetLoss
from wetnet.metrics import dice_confusion, hd95, iou_lesion

try:
    from scipy.ndimage import binary_fill_holes, label
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False


def topology_stats(mask: np.ndarray):
    """(#connected components, #interior holes) of a binary mask."""
    if not _HAS_SCIPY or not mask.any():
        return 0, 0
    _, ncomp = label(mask)
    holes = int((binary_fill_holes(mask) & ~mask.astype(bool)).sum() > 0)
    _, nholes = label(binary_fill_holes(mask) & ~mask.astype(bool))
    return int(ncomp), int(nholes)


def run(lambda_topo, epochs, size, n_train, n_test, seed, device, noise, topo_size):
    torch.manual_seed(seed)
    np.random.seed(seed)
    tr = DataLoader(SyntheticLesions(n_train, size, seed=0, p_satellite=0.9, p_hole=0.9,
                                     noise=noise), batch_size=8, shuffle=True)
    te = DataLoader(SyntheticLesions(n_test, size, seed=999, p_satellite=0.9, p_hole=0.9,
                                     noise=noise), batch_size=8)

    model = WETNet(WETNetConfig(tar_stride=2, widths=(16, 32, 64, 96))).to(device)
    crit = WETNetLoss(LossWeights(1.0, 1.0, 0.1, lambda_topo), topo_size=topo_size or size)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=1e-5)

    hist = []
    for ep in range(epochs):
        model.train()
        agg, t0 = {}, time.time()
        for x, y in tr:
            x, y = x.to(device), y.to(device)
            opt.zero_grad()
            parts = crit(model(x), y)
            parts["loss"].backward()
            opt.step()
            for k, v in parts.items():
                agg[k] = agg.get(k, 0.0) + float(v)
        sched.step()
        hist.append({"epoch": ep, **{k: round(v / len(tr), 4) for k, v in agg.items()},
                     "sec": round(time.time() - t0, 1)})
        print(f"  [lambda_topo={lambda_topo}] {hist[-1]}", flush=True)

    model.eval()
    ious, dices, hds, comps, holes = [], [], [], [], []
    preds, gts, imgs = [], [], []
    with torch.no_grad():
        for x, y in te:
            p = torch.sigmoid(model(x.to(device))["logits"]).cpu().numpy()[:, 0]
            for i in range(p.shape[0]):
                m = (p[i] > 0.5).astype(np.uint8)
                t = y.numpy()[i, 0].astype(np.uint8)
                ious.append(iou_lesion(m, t)); dices.append(dice_confusion(m, t))
                hds.append(hd95(m, t))
                c, h = topology_stats(m)
                comps.append(c); holes.append(h)
                if len(preds) < 4:
                    preds.append(m); gts.append(t); imgs.append(x.numpy()[i, 0])
    return {
        "lambda_topo": lambda_topo,
        "miou_pct": round(100 * float(np.mean(ious)), 2),
        "dice_pct": round(100 * float(np.mean(dices)), 2),
        "hd95_px": round(float(np.mean(hds)), 2),
        "mean_components": round(float(np.mean(comps)), 3),
        "frac_multi_component": round(float(np.mean([c > 1 for c in comps])), 3),
        "mean_holes": round(float(np.mean(holes)), 3),
        "history": hist,
    }, (imgs, gts, preds)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--size", type=int, default=96)
    ap.add_argument("--n-train", type=int, default=64)
    ap.add_argument("--n-test", type=int, default=32)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--noise", type=float, default=0.45)
    ap.add_argument("--topo-size", type=int, default=0)
    ap.add_argument("--out", default="results/smoke_test.json")
    a = ap.parse_args()

    out = {}
    panels = {}
    for lt in (0.0, 0.1):
        r, pan = run(lt, a.epochs, a.size, a.n_train, a.n_test, 42, a.device,
                     a.noise, a.topo_size)
        out[f"lambda_topo={lt}"] = r
        panels[lt] = pan
        print(json.dumps({k: v for k, v in r.items() if k != "history"}))

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w") as fh:
        json.dump({"note": "SYNTHETIC DATA ONLY - not a benchmark", "runs": out}, fh, indent=2)
    print("wrote", a.out)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        n = len(panels[0.1][0])
        fig, ax = plt.subplots(4, n, figsize=(2.2 * n, 8.8))
        rows = [("input", panels[0.1][0]), ("ground truth", panels[0.1][1]),
                ("pred, lambda_topo=0", panels[0.0][2]), ("pred, lambda_topo=0.1", panels[0.1][2])]
        for r, (name, data) in enumerate(rows):
            for c in range(n):
                ax[r, c].imshow(data[c], cmap="gray"); ax[r, c].axis("off")
                if c == 0:
                    ax[r, c].set_title(name, loc="left", fontsize=9)
        fig.tight_layout()
        fig.savefig("results/smoke_test_panels.png", dpi=110)
        print("wrote results/smoke_test_panels.png")
    except Exception as e:
        print("figure skipped:", e)


if __name__ == "__main__":
    main()
