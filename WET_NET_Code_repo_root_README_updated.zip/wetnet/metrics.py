"""Segmentation and calibration metrics, reported exactly as the revised manuscript reports them.

Reviewer #4, comment 6, asked us to check the Dice formula.  It is correct, and both forms are
implemented here with ``test_metrics.py`` asserting they agree:

    confusion form   Dice = 2 Tp / (2 Tp + Fp + Fn)
    set form         Dice = 2 |A n B| / (|A| + |B|)

The check also exposed a labelling ambiguity one equation earlier, which the revision now
states explicitly and which this module encodes: what the manuscript (and the lightweight
skin-lesion literature it compares against) calls ``mIoU`` is the intersection over union of
the *lesion class alone*,

    IoU = Tp / (Tp + Fp + Fn)

not an intersection over union averaged over foreground and background.  ``iou_lesion`` is
that quantity; ``iou_macro`` is the class-averaged variant, provided so the difference is
visible rather than implicit.  For a single image the two headline metrics are related by
``Dice = 2 IoU / (1 + IoU)``; because the reported columns average *per-image* scores rather
than pooling confusion matrices, the identity holds only approximately over a dataset.

Reporting convention (Reviewer #1, major comments 2 and 3): region-level metrics are returned
as fractions and formatted as percentages with two decimals by ``format_row``; HD95 stays in
pixels.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional

import numpy as np

try:
    from scipy.ndimage import binary_erosion, distance_transform_edt

    _HAS_SCIPY = True
except Exception:                                        # pragma: no cover
    _HAS_SCIPY = False

EPS = 1e-7


# --------------------------------------------------------------------------------------
def confusion(pred: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    p = pred.astype(bool)
    t = target.astype(bool)
    return {
        "tp": float(np.logical_and(p, t).sum()),
        "tn": float(np.logical_and(~p, ~t).sum()),
        "fp": float(np.logical_and(p, ~t).sum()),
        "fn": float(np.logical_and(~p, t).sum()),
    }


def iou_lesion(pred, target) -> float:
    c = confusion(pred, target)
    return c["tp"] / (c["tp"] + c["fp"] + c["fn"] + EPS)


def iou_macro(pred, target) -> float:
    """Class-averaged IoU, i.e. the literal reading of 'mean IoU'.  Not what Table VIII reports."""
    c = confusion(pred, target)
    fg = c["tp"] / (c["tp"] + c["fp"] + c["fn"] + EPS)
    bg = c["tn"] / (c["tn"] + c["fn"] + c["fp"] + EPS)
    return 0.5 * (fg + bg)


def dice_confusion(pred, target) -> float:
    c = confusion(pred, target)
    return 2 * c["tp"] / (2 * c["tp"] + c["fp"] + c["fn"] + EPS)


def dice_set(pred, target) -> float:
    """2 |A n B| / (|A| + |B|) -- the set-theoretic form, for the equivalence test."""
    p = pred.astype(bool)
    t = target.astype(bool)
    return 2 * np.logical_and(p, t).sum() / (p.sum() + t.sum() + EPS)


def accuracy(pred, target) -> float:
    c = confusion(pred, target)
    return (c["tp"] + c["tn"]) / (c["tp"] + c["tn"] + c["fp"] + c["fn"] + EPS)


def specificity(pred, target) -> float:
    c = confusion(pred, target)
    return c["tn"] / (c["tn"] + c["fp"] + EPS)


def sensitivity(pred, target) -> float:
    c = confusion(pred, target)
    return c["tp"] / (c["tp"] + c["fn"] + EPS)


# --------------------------------------------------------------------------------------
def _boundary(mask: np.ndarray) -> np.ndarray:
    if not mask.any():
        return mask
    if _HAS_SCIPY:
        return np.logical_xor(mask, binary_erosion(mask, iterations=1, border_value=0))
    inner = np.zeros_like(mask)
    inner[1:-1, 1:-1] = mask[1:-1, 1:-1]
    return np.logical_xor(mask, inner)


def hd95(pred: np.ndarray, target: np.ndarray, spacing: float = 1.0) -> float:
    """95th-percentile symmetric Hausdorff distance in pixels."""
    if not _HAS_SCIPY:                                   # pragma: no cover
        raise RuntimeError("HD95 needs scipy")
    p, t = _boundary(pred.astype(bool)), _boundary(target.astype(bool))
    if not p.any() or not t.any():
        return float(np.hypot(*pred.shape))              # degenerate: image diagonal
    dt_t = distance_transform_edt(~t) * spacing
    dt_p = distance_transform_edt(~p) * spacing
    d = np.concatenate([dt_t[p], dt_p[t]])
    return float(np.percentile(d, 95))


# --------------------------------------------------------------------------------------
def expected_calibration_error(prob: np.ndarray, target: np.ndarray, n_bins: int = 15) -> float:
    """ECE over ``n_bins`` equally spaced confidence bins (Guo et al., [21]).

    Confidence is ``max(p, 1 - p)`` and correctness is whether the thresholded prediction
    matches the label, which is the standard binary formulation.
    """
    prob = prob.ravel()
    target = target.ravel().astype(bool)
    conf = np.maximum(prob, 1.0 - prob)
    correct = ((prob > 0.5) == target)
    edges = np.linspace(0.5, 1.0, n_bins + 1)
    ece, n = 0.0, conf.size
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if not m.any():
            continue
        ece += m.sum() / n * abs(correct[m].mean() - conf[m].mean())
    return float(ece)


# --------------------------------------------------------------------------------------
def evaluate(preds: Iterable[np.ndarray], targets: Iterable[np.ndarray],
             probs: Optional[Iterable[np.ndarray]] = None) -> Dict[str, float]:
    """Per-image metrics averaged over the dataset, as in Table II of the manuscript."""
    acc: Dict[str, List[float]] = {k: [] for k in
                                   ("miou", "iou_macro", "dice", "acc", "sp", "se", "hd95")}
    probs = list(probs) if probs is not None else None
    ece_num: List[float] = []
    for i, (p, t) in enumerate(zip(preds, targets)):
        acc["miou"].append(iou_lesion(p, t))
        acc["iou_macro"].append(iou_macro(p, t))
        acc["dice"].append(dice_confusion(p, t))
        acc["acc"].append(accuracy(p, t))
        acc["sp"].append(specificity(p, t))
        acc["se"].append(sensitivity(p, t))
        acc["hd95"].append(hd95(p, t))
        if probs is not None:
            ece_num.append(expected_calibration_error(probs[i], t))
    out = {k: float(np.mean(v)) for k, v in acc.items() if v}
    if ece_num:
        out["ece"] = float(np.mean(ece_num))
    return out


def format_row(m: Dict[str, float]) -> Dict[str, str]:
    """Percentages with two decimals; HD95 in pixels with two decimals."""
    out = {}
    for k, v in m.items():
        out[k] = f"{v:.2f}" if k == "hd95" else f"{100 * v:.2f}"
    return out
