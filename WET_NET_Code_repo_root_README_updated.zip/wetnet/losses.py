"""Composite objective: BCE + Dice + evidential calibration + topological penalty.

    L = l_bce * L_bce + l_dice * L_dice + l_ev * L_ev + l_topo * L_topo

with (1.0, 1.0, 0.1, 0.1) as in the manuscript.

``L_ev`` is the Kullback-Leibler divergence between the Dirichlet posterior restricted to the
*incorrect* classes and the uniform Dirichlet, following Sensoy et al. [19].  It penalises
evidence assigned to wrong classes without penalising confident correct predictions, which is
what keeps the uncertainty map calibrated rather than merely small.

``L_topo`` is the differentiable persistence loss of ``layers/persistence.py``.  Because the
pairing is combinatorial and runs on CPU, it is evaluated on a downsampled probability map and
only every ``topo_every`` steps by default -- both are configurable and both are reported in
the training log so the cost is never hidden.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers.persistence import topological_loss


def dice_loss(logits: torch.Tensor, target: torch.Tensor, eps: float = 1.0) -> torch.Tensor:
    """Soft Dice.  Matches the confusion-matrix form 2Tp / (2Tp + Fp + Fn) at the hard limit."""
    prob = torch.sigmoid(logits)
    dims = tuple(range(1, prob.dim()))
    inter = (prob * target).sum(dims)
    denom = prob.sum(dims) + target.sum(dims)
    return (1.0 - (2.0 * inter + eps) / (denom + eps)).mean()


def evidential_kl(alphas: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """KL( Dir(alpha_tilde) || Dir(1) ) with alpha_tilde the wrong-class concentrations.

    ``alphas``: (B, n_bands, K, h, w) from the WEB evidential heads.
    ``target``: (B, 1, H, W) binary; downsampled to the band resolution.
    """
    b, nb, k, h, w = alphas.shape
    y = F.interpolate(target.float(), size=(h, w), mode="nearest")            # (B,1,h,w)
    onehot = torch.cat([1.0 - y, y], dim=1) if k == 2 else y.expand(-1, k, -1, -1)
    onehot = onehot.unsqueeze(1).expand(-1, nb, -1, -1, -1)                   # (B,nb,K,h,w)

    alpha_t = onehot + (1.0 - onehot) * alphas          # keep 1 on the true class
    s = alpha_t.sum(dim=2, keepdim=True)
    kl = (torch.lgamma(s.squeeze(2)) - torch.lgamma(alpha_t).sum(2)
          - torch.lgamma(torch.tensor(float(k), device=alphas.device))
          + ((alpha_t - 1.0) * (torch.digamma(alpha_t) - torch.digamma(s))).sum(2))
    return kl.mean()


@dataclass
class LossWeights:
    bce: float = 1.0
    dice: float = 1.0
    ev: float = 0.1
    topo: float = 0.1


class WETNetLoss(nn.Module):
    def __init__(self, weights: LossWeights | None = None, topo_size: int = 64,
                 topo_every: int = 1):
        super().__init__()
        self.w = weights or LossWeights()
        self.topo_size = topo_size
        self.topo_every = max(1, int(topo_every))
        self._step = 0

    def forward(self, out: Dict[str, torch.Tensor], target: torch.Tensor
                ) -> Dict[str, torch.Tensor]:
        logits = out["logits"]
        target = target.float()

        l_bce = F.binary_cross_entropy_with_logits(logits, target)
        l_dice = dice_loss(logits, target)

        l_ev = logits.new_zeros(())
        if out.get("alphas") is not None and self.w.ev > 0:
            l_ev = evidential_kl(out["alphas"], target)

        l_topo = logits.new_zeros(())
        if self.w.topo > 0 and self._step % self.topo_every == 0:
            prob = torch.sigmoid(logits)
            if self.topo_size and prob.shape[-1] > self.topo_size:
                prob = F.interpolate(prob, size=(self.topo_size, self.topo_size),
                                     mode="bilinear", align_corners=False)
            l_topo = topological_loss(prob)
        self._step += 1

        total = (self.w.bce * l_bce + self.w.dice * l_dice
                 + self.w.ev * l_ev + self.w.topo * l_topo)
        return {"loss": total, "bce": l_bce.detach(), "dice": l_dice.detach(),
                "ev": l_ev.detach(), "topo": l_topo.detach()}
