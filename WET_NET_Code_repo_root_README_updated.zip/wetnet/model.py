"""WET-Net: Wavelet-Evidential Topology-aware network for skin-lesion segmentation.

Data path (Fig. 2 of the manuscript, traced in the revised Section III-A):

    x (3, 256, 256)
      -> LRRE encoder      F1 (16,128,128)  F2 (32,64,64)  F3 (64,32,32)  F4 (96,16,16)
      -> WEB bridge        F4 -> F_bridge, same shape; emits the uncertainty map
      -> LRRE decoder      96->64 @32, 64->32 @64, 32->16 @128, then a 1x1 head
      -> coarse logits, upsampled to full resolution
      -> TAR               refined logits  +  uncertainty map

Every module can be swapped from the command line so that Tables III to VII of the paper are
reproduced by the same code path that produces Table VIII:

    encoder  lrre | resnet18 | resnet34 | mobilenetv3_small          (Table III)
    bridge   web | pdcp | aspp | spp | doubleconv                    (Table V)
    fusion   evidential | se | static | uniform                      (Table VI)
    wavelet  db2 | db5 | db7  and  levels                            (Table VII)
    tar      on | off                                                (Table IV)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers.lrre import LRREDecoder, build_encoder
from .layers.tar import TAR
from .layers.web import WEB, build_bridge


@dataclass
class WETNetConfig:
    in_ch: int = 3
    num_classes: int = 2
    widths: Sequence[int] = (16, 32, 64, 96)
    encoder: str = "lrre"
    bridge: str = "web"
    fusion: str = "evidential"
    wavelet: str = "db5"
    n_stages: int = 5
    levels: int = 2
    use_tar: bool = True
    decoder_out: int = 16
    tar_hidden: int = 16
    tar_topo_dim: int = 32
    tar_stride: int = 2          # TAR runs at input/tar_stride resolution, then upsamples
    blocks_per_stage: int = 1    # LRRE blocks per encoder/decoder stage


class WETNet(nn.Module):
    def __init__(self, cfg: WETNetConfig | None = None, **kw):
        super().__init__()
        cfg = cfg or WETNetConfig()
        for k, v in kw.items():
            setattr(cfg, k, v)
        self.cfg = cfg

        self.encoder, widths = build_encoder(cfg.encoder, cfg.in_ch, cfg.widths,
                                             cfg.blocks_per_stage)
        deep = widths[-1]

        if cfg.bridge == "web":
            self.bridge = WEB(deep, levels=cfg.levels, fusion=cfg.fusion,
                              num_classes=cfg.num_classes, n_stages=cfg.n_stages,
                              wavelet=cfg.wavelet)
        else:
            self.bridge = build_bridge(cfg.bridge, deep)

        self.decoder = LRREDecoder(widths, cfg.decoder_out, cfg.blocks_per_stage)
        self.coarse_head = nn.Conv2d(cfg.decoder_out, 1, kernel_size=1)
        self.tar = TAR(cfg.decoder_out, cfg.tar_hidden, cfg.tar_topo_dim) if cfg.use_tar else None

    # ----------------------------------------------------------------------------------
    def forward(self, x: torch.Tensor):
        size = x.shape[-2:]
        feats: List[torch.Tensor] = self.encoder(x)

        out = self.bridge(feats[-1])
        if isinstance(out, tuple):
            f_bridge, unc, alphas, weights = out
        else:                                        # plain nn.Sequential bridges
            f_bridge, unc, alphas, weights = out, None, None, None

        dec = self.decoder(f_bridge, feats)
        coarse = self.coarse_head(dec)
        coarse = F.interpolate(coarse, size=size, mode="bilinear", align_corners=False)

        if self.tar is not None:
            s_ = max(1, int(self.cfg.tar_stride))
            work = (size[0] // s_, size[1] // s_)
            dec_w = F.interpolate(dec, size=work, mode="bilinear", align_corners=False)
            prob_w = F.interpolate(torch.sigmoid(coarse), size=work,
                                   mode="bilinear", align_corners=False)
            logits = self.tar(dec_w, prob_w)
            if work != tuple(size):
                logits = F.interpolate(logits, size=size, mode="bilinear", align_corners=False)
        else:
            logits = coarse

        if unc is not None:
            unc = F.interpolate(unc, size=size, mode="bilinear", align_corners=False)

        return {
            "logits": logits,
            "coarse_logits": coarse,
            "uncertainty": unc,
            "alphas": alphas,
            "band_weights": weights,
        }

    # ----------------------------------------------------------------------------------
    @torch.no_grad()
    def predict(self, x: torch.Tensor, threshold: float = 0.5):
        out = self(x)
        prob = torch.sigmoid(out["logits"])
        return (prob > threshold).float(), prob, out["uncertainty"]

    # -- parameter accounting, reported both ways for Table III (Reviewer #3) ----------
    def parameter_report(self) -> dict:
        def count(m: Optional[nn.Module]) -> int:
            return 0 if m is None else sum(p.numel() for p in m.parameters())

        enc = count(self.encoder)
        total = count(self)
        return {
            "encoder_params": enc,
            "bridge_params": count(self.bridge),
            "decoder_params": count(self.decoder) + count(self.coarse_head),
            "tar_params": count(self.tar),
            "total_params": total,
            "encoder_params_M": enc / 1e6,
            "total_params_M": total / 1e6,
        }


def build_model(**kw) -> WETNet:
    return WETNet(WETNetConfig(), **kw)
