"""Parameter, MAC and latency accounting.

Reviewer #3's comment turned on the fact that the manuscript quoted an encoder-only figure in
one place and a whole-network figure in another without saying so.  This module therefore
always reports *both*, and every number it prints is measured from the instantiated model
rather than copied from anywhere.

FLOP convention: one multiply-accumulate is counted as one FLOP, which is the convention
used by ``thop`` and ``fvcore`` and hence by the baselines quoted in Table VIII.  Doubling
these numbers gives the "2 x MAC" convention some papers use instead; the ratio between
models is unaffected either way.
"""

from __future__ import annotations

import time
from typing import Dict, Iterable, Tuple

import torch
import torch.nn as nn


def count_macs(model: nn.Module, input_size: Tuple[int, ...] = (1, 3, 256, 256),
               device: str = "cpu") -> int:
    """Multiply-accumulates for one forward pass, via hooks on the arithmetic layers."""
    total = {"macs": 0}
    handles = []

    def conv_hook(mod, inp, out):
        oc, oh, ow = out.shape[1], out.shape[-2], out.shape[-1]
        kh, kw = mod.kernel_size
        total["macs"] += oh * ow * oc * (mod.in_channels // mod.groups) * kh * kw

    def linear_hook(mod, inp, out):
        total["macs"] += int(out.numel() / out.shape[-1]) * mod.in_features * mod.out_features

    def wavelet_hook(mod, inp, out):
        # the wavelet transform is tensor algebra, not a conv, so a conv-only counter would
        # silently omit it; this accounts for the lattice rotations explicitly
        total["macs"] += mod.macs_for(inp[0].numel())

    from .layers.dtcwt import DualTreeDWT2D

    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            handles.append(m.register_forward_hook(conv_hook))
        elif isinstance(m, nn.Linear):
            handles.append(m.register_forward_hook(linear_hook))
        elif isinstance(m, DualTreeDWT2D):
            handles.append(m.register_forward_hook(wavelet_hook))

    was_training = model.training
    model.eval().to(device)
    with torch.no_grad():
        model(torch.randn(*input_size, device=device))
    for h in handles:
        h.remove()
    model.train(was_training)
    return total["macs"]


@torch.no_grad()
def measure_latency(model: nn.Module, input_size=(1, 3, 256, 256), device: str = "cpu",
                    warmup: int = 3, runs: int = 10) -> float:
    """Mean forward-pass wall time in milliseconds."""
    model.eval().to(device)
    x = torch.randn(*input_size, device=device)
    for _ in range(warmup):
        model(x)
    if device.startswith("cuda"):
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(runs):
        model(x)
    if device.startswith("cuda"):
        torch.cuda.synchronize()
    return (time.perf_counter() - t0) * 1000.0 / runs


def summarise(model, input_size=(1, 3, 256, 256), device: str = "cpu",
              latency: bool = True) -> Dict[str, float]:
    rep = model.parameter_report() if hasattr(model, "parameter_report") else {
        "encoder_params": 0, "total_params": sum(p.numel() for p in model.parameters())
    }
    macs = count_macs(model, input_size, device)
    out = {
        "encoder_params_M": rep["encoder_params"] / 1e6,
        "total_params_M": rep["total_params"] / 1e6,
        "gflops": macs / 1e9,
    }
    if latency:
        out["latency_ms"] = measure_latency(model, input_size, device)
    return out
