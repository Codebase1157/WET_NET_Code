"""Datasets.

``SkinLesionDataset`` reads any of ISIC2018, ISIC2017, HAM10000 or PH2 from a directory pair
(images/, masks/) plus an explicit index list, so that the exact train/test split used for a
run is a file in the repository rather than a shuffle seed.  That is what makes the numbers
reproducible rather than merely re-derivable, and it is why the Code and Data Availability
section of the revised manuscript promises the index lists alongside the weights.

``SyntheticLesions`` generates blob-shaped lesions with controllable satellite specks and
punched-out holes.  It exists so that the topological machinery can be exercised end to end
without any patient data -- ``scripts/smoke_test.py`` uses it, and so does the demonstration
in ``results/`` that the persistence loss removes exactly the artefacts it is supposed to.
It is NOT a benchmark: no accuracy figure derived from it belongs in the paper.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


# --------------------------------------------------------------------------------------
class SkinLesionDataset(Dataset):
    def __init__(self, image_dir: str, mask_dir: str, index_file: Optional[str] = None,
                 size: int = 256, augment: bool = False, mask_suffix: str = "_segmentation"):
        self.image_dir = Path(image_dir)
        self.mask_dir = Path(mask_dir)
        self.size = size
        self.augment = augment
        self.mask_suffix = mask_suffix

        if index_file and os.path.exists(index_file):
            with open(index_file) as fh:
                self.ids = [ln.strip() for ln in fh if ln.strip()]
        else:
            self.ids = sorted(p.stem for p in self.image_dir.iterdir()
                              if p.suffix.lower() in IMG_EXT)

    def __len__(self) -> int:
        return len(self.ids)

    def _find(self, directory: Path, stem: str) -> Path:
        for ext in IMG_EXT:
            p = directory / f"{stem}{ext}"
            if p.exists():
                return p
        raise FileNotFoundError(f"no file for {stem!r} in {directory}")

    def __getitem__(self, i: int):
        from PIL import Image

        stem = self.ids[i]
        img = Image.open(self._find(self.image_dir, stem)).convert("RGB")
        try:
            mask_path = self._find(self.mask_dir, stem + self.mask_suffix)
        except FileNotFoundError:
            mask_path = self._find(self.mask_dir, stem)
        msk = Image.open(mask_path).convert("L")

        img = img.resize((self.size, self.size), Image.BILINEAR)
        msk = msk.resize((self.size, self.size), Image.NEAREST)
        x = np.asarray(img, dtype=np.float32) / 255.0
        y = (np.asarray(msk, dtype=np.float32) > 127).astype(np.float32)

        if self.augment:
            if np.random.rand() < 0.5:
                x, y = x[:, ::-1], y[:, ::-1]
            if np.random.rand() < 0.5:
                x, y = x[::-1], y[::-1]
            if np.random.rand() < 0.5:                      # mild colour jitter
                x = np.clip(x * np.random.uniform(0.9, 1.1, size=(1, 1, 3))
                            + np.random.uniform(-0.05, 0.05), 0, 1)

        x = torch.from_numpy(np.ascontiguousarray(x.transpose(2, 0, 1)))
        y = torch.from_numpy(np.ascontiguousarray(y))[None]
        return x, y


# --------------------------------------------------------------------------------------
class SyntheticLesions(Dataset):
    """Blob lesions with optional satellite components and holes, for smoke tests only."""

    def __init__(self, n: int = 64, size: int = 128, seed: int = 0,
                 p_satellite: float = 0.5, p_hole: float = 0.4, noise: float = 0.25):
        self.n, self.size = n, size
        self.seed, self.p_sat, self.p_hole, self.noise = seed, p_satellite, p_hole, noise

    def __len__(self) -> int:
        return self.n

    def __getitem__(self, i: int):
        rng = np.random.default_rng(self.seed * 100003 + i)
        s = self.size
        yy, xx = np.mgrid[0:s, 0:s]

        cy, cx = rng.integers(s // 3, 2 * s // 3, size=2)
        r = rng.integers(s // 6, s // 4)
        theta = np.arctan2(yy - cy, xx - cx)
        wobble = 1.0 + 0.22 * np.sin(3 * theta + rng.uniform(0, 6.28)) \
                     + 0.12 * np.sin(5 * theta + rng.uniform(0, 6.28))
        mask = ((yy - cy) ** 2 + (xx - cx) ** 2) < (r * wobble) ** 2

        truth = mask.copy()                        # ground truth: one component, no holes
        img = mask.astype(np.float32)

        if rng.random() < self.p_sat:              # satellite speck: appearance only
            sy, sx = rng.integers(4, s - 4, size=2)
            img[((yy - sy) ** 2 + (xx - sx) ** 2) < rng.integers(2, 5) ** 2] = 1.0
        if rng.random() < self.p_hole:             # punched-out hole: appearance only
            img[((yy - cy) ** 2 + (xx - cx) ** 2) < (r // 3) ** 2] = 0.0

        img = 0.25 + 0.5 * img
        img = np.clip(img + self.noise * rng.normal(size=img.shape), 0, 1).astype(np.float32)
        x = torch.from_numpy(np.stack([img] * 3, 0))
        y = torch.from_numpy(truth.astype(np.float32))[None]
        return x, y


def write_index(ids: Sequence[str], path: str) -> None:
    with open(path, "w") as fh:
        fh.write("\n".join(ids) + "\n")
