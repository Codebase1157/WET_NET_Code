"""Topology-Aware Refinement (TAR): PersLay descriptor + cross-attention fusion.

Two branches, as in Fig. 5 of the manuscript:

  spatial   3x3 conv -> GELU -> LayerNorm on the decoder feature concatenated with the
            coarse probability map.
  topology  cubical filtration -> persistence diagram -> PersLay descriptor.

The branches are merged by cross-attention with queries from the spatial branch and keys and
values from the topological branch, then a 1x1 convolution emits the refined map.

Implementation note (documented because it is a deviation from the plain reading of the
paper): a full-resolution query grid against a handful of topological tokens would spend most
of its cost on the query projection.  Attention is therefore computed at 1/4 of the decoder
resolution and the attended residual is bilinearly upsampled before the output convolution.
The topological descriptor is global, so nothing is lost by attending at reduced resolution,
and the module stays inside the GFLOP budget reported in Table VIII.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .persistence import persistence_diagram


class PersLay(nn.Module):
    """Permutation-invariant embedding of a persistence diagram (Carriere et al., [23]).

    Each point (birth, death, dim) is lifted by a learnable point transformer ``psi`` and
    the lifted points are combined by a learnable weighting, giving a fixed-size descriptor
    regardless of how many topological features the map happens to contain.
    """

    def __init__(self, dim: int = 32, n_tokens: int = 4, max_points: int = 32):
        super().__init__()
        self.max_points = max_points
        self.n_tokens = n_tokens
        self.dim = dim
        self.psi = nn.Sequential(nn.Linear(4, dim), nn.GELU(), nn.Linear(dim, dim))
        self.weight = nn.Sequential(nn.Linear(4, dim // 2), nn.GELU(), nn.Linear(dim // 2, 1))
        self.to_tokens = nn.Linear(dim, n_tokens * dim)

    @torch.no_grad()
    def _diagrams(self, prob: torch.Tensor) -> torch.Tensor:
        """(B, max_points, 4): birth, death, persistence, homology dim.  Zero-padded."""
        b = prob.shape[0]
        out = np.zeros((b, self.max_points, 4), dtype=np.float32)
        arr = prob.detach().float().cpu().numpy()
        for i in range(b):
            dgm = persistence_diagram(arr[i], self.max_points)
            if dgm.size:
                n = dgm.shape[0]
                out[i, :n, 0] = dgm[:, 0]
                out[i, :n, 1] = dgm[:, 1]
                out[i, :n, 2] = np.abs(dgm[:, 0] - dgm[:, 1])
                out[i, :n, 3] = dgm[:, 2]
        return torch.from_numpy(out).to(prob.device)

    def forward(self, prob: torch.Tensor) -> torch.Tensor:
        pts = self._diagrams(prob)                       # (B, P, 4)
        mask = (pts.abs().sum(-1, keepdim=True) > 0).float()
        lifted = self.psi(pts) * mask                    # (B, P, D)
        w = torch.sigmoid(self.weight(pts)) * mask       # (B, P, 1)
        desc = (lifted * w).sum(dim=1)                   # (B, D)  permutation invariant
        return self.to_tokens(desc).view(-1, self.n_tokens, self.dim)


class TAR(nn.Module):
    def __init__(self, in_ch: int, hidden: int = 16, topo_dim: int = 32, n_tokens: int = 4,
                 attn_stride: int = 4):
        super().__init__()
        self.attn_stride = attn_stride
        self.spatial = nn.Sequential(
            nn.Conv2d(in_ch + 1, hidden, kernel_size=3, padding=1, bias=False),
            nn.GELU(), nn.GroupNorm(1, hidden),          # LayerNorm over (C, H, W)
        )
        self.perslay = PersLay(topo_dim, n_tokens)
        self.q = nn.Conv2d(hidden, topo_dim, kernel_size=1, bias=False)
        self.k = nn.Linear(topo_dim, topo_dim, bias=False)
        self.v = nn.Linear(topo_dim, topo_dim, bias=False)
        self.merge = nn.Conv2d(topo_dim, hidden, kernel_size=1, bias=False)
        self.out = nn.Conv2d(hidden, 1, kernel_size=1)
        self.scale = topo_dim ** -0.5

    def forward(self, feat: torch.Tensor, coarse_prob: torch.Tensor) -> torch.Tensor:
        x = self.spatial(torch.cat([feat, coarse_prob], dim=1))
        b, c, h, w = x.shape

        tokens = self.perslay(coarse_prob[:, 0])                       # (B, T, D)
        k = self.k(tokens)                                             # (B, T, D)
        v = self.v(tokens)

        qs = F.avg_pool2d(x, self.attn_stride) if self.attn_stride > 1 else x
        q = self.q(qs)                                                 # (B, D, h', w')
        bh, bw = q.shape[-2:]
        q = q.flatten(2).transpose(1, 2)                               # (B, N, D)
        attn = torch.softmax(q @ k.transpose(1, 2) * self.scale, dim=-1)
        ctx = (attn @ v).transpose(1, 2).reshape(b, -1, bh, bw)        # (B, D, h', w')
        ctx = F.interpolate(ctx, size=(h, w), mode="bilinear", align_corners=False)

        return self.out(x + self.merge(ctx))                           # refined logits
