"""Differentiable 0- and 1-dimensional cubical persistent homology.

Follows the construction of Hu et al. (NeurIPS 2019), reference [44] in the revised
manuscript: persistence pairs are computed on the *values* of the probability map by a
non-differentiable combinatorial routine, which returns the **pixel indices** at which each
topological feature is born and dies.  The loss is then assembled in torch by gathering the
map at those indices, so gradients flow to exactly the pixels that created or destroyed a
feature.  The pairing itself is piecewise constant in the input and needs no gradient.

Two backends:

  * ``gudhi`` (preferred) -- ``CubicalComplex.cofaces_of_persistence_pairs()`` gives the
    birth/death pixel indices directly, for both homology dimensions.
  * a dependency-free union-find fallback for H0, with H1 obtained from the Euler relation
    on the complement.  Used only if gudhi is not installed; it is slower and H1 is
    approximate, so gudhi is listed in requirements.txt.

For a lesion mask the target topology is exactly one connected component and no holes, so

    L_topo = sum over all H0 pairs except the most persistent of (d - b)^2
           + sum over all H1 pairs                              of (d - b)^2

which drives every spurious satellite component and every punched-out hole to zero
persistence while leaving the single true component untouched.
"""

from __future__ import annotations

from typing import List, Tuple

import numpy as np
import torch

try:                                                     # pragma: no cover - optional dep
    import gudhi

    _HAS_GUDHI = True
except Exception:                                        # pragma: no cover
    _HAS_GUDHI = False

Pair = Tuple[int, int]                                   # flat pixel indices (birth, death)


# --------------------------------------------------------------------------------------
def _pairs_gudhi(img: np.ndarray) -> Tuple[List[Pair], List[Pair]]:
    """Persistence pairs of the *superlevel* filtration of ``img`` (H, W), as pixel indices."""
    cc = gudhi.CubicalComplex(top_dimensional_cells=(-img).ravel(), dimensions=img.shape[::-1])
    cc.compute_persistence(homology_coeff_field=2)
    regular, essential = cc.cofaces_of_persistence_pairs()

    h0: List[Pair] = []
    h1: List[Pair] = []
    for dim, arr in enumerate(regular):
        if arr is None or len(arr) == 0:
            continue
        target = h0 if dim == 0 else (h1 if dim == 1 else None)
        if target is None:
            continue
        for b, d in np.asarray(arr).reshape(-1, 2):
            target.append((int(b), int(d)))
    # essential H0 class (the global maximum) never dies; it is the component we keep
    return h0, h1


# --------------------------------------------------------------------------------------
def _pairs_unionfind(img: np.ndarray) -> Tuple[List[Pair], List[Pair]]:
    """Fallback: H0 of the superlevel filtration by union-find; H1 by the dual filtration."""

    def h0_pairs(v: np.ndarray) -> List[Pair]:
        h, w = v.shape
        order = np.argsort(-v.ravel(), kind="stable")
        parent = np.full(v.size, -1, dtype=np.int64)
        root_birth = {}
        pairs: List[Pair] = []

        def find(a: int) -> int:
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        for idx in order:
            r, c = divmod(int(idx), w)
            parent[idx] = idx
            root_birth[idx] = idx
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                rr, cc_ = r + dr, c + dc
                if not (0 <= rr < h and 0 <= cc_ < w):
                    continue
                nb = rr * w + cc_
                if parent[nb] == -1:
                    continue
                ra, rb = find(int(idx)), find(nb)
                if ra == rb:
                    continue
                ba, bb = root_birth[ra], root_birth[rb]
                # the younger component (lower birth value) dies here
                if v.ravel()[ba] < v.ravel()[bb]:
                    young, old = ba, bb
                    parent[ra] = rb
                    root_birth[rb] = old
                else:
                    young, old = bb, ba
                    parent[rb] = ra
                    root_birth[ra] = old
                pairs.append((int(young), int(idx)))
        return pairs

    flat = img.ravel()

    def drop_trivial(pairs: List[Pair]) -> List[Pair]:
        # zero-persistence pairs carry no gradient and are omitted by gudhi as well
        return [(b, d) for b, d in pairs if abs(float(flat[b]) - float(flat[d])) > 0.0]

    h0 = drop_trivial(h0_pairs(img))
    h1 = drop_trivial([(d, b) for b, d in h0_pairs(-img)])   # holes of the superlevel set
    return h0, h1


def persistence_pairs(img: np.ndarray) -> Tuple[List[Pair], List[Pair]]:
    fn = _pairs_gudhi if _HAS_GUDHI else _pairs_unionfind
    return fn(np.ascontiguousarray(img, dtype=np.float64))


# --------------------------------------------------------------------------------------
def topological_loss(prob: torch.Tensor, max_pairs: int = 64) -> torch.Tensor:
    """Differentiable persistence loss for a batch of probability maps.

    ``prob``: (B, 1, H, W) or (B, H, W) in [0, 1].  Returns a scalar.

    Gradients reach ``prob`` through the gathered birth/death pixel values; the pairing is
    treated as a constant, exactly as in Hu et al.
    """
    if prob.dim() == 4:
        prob = prob[:, 0]
    b, h, w = prob.shape
    flat = prob.reshape(b, -1)
    detached = flat.detach().cpu().numpy()
    total = flat.sum() * 0.0            # keeps the result attached to the graph when empty
    for i in range(b):
        img = detached[i].reshape(h, w)
        h0, h1 = persistence_pairs(img)
        # NOTE: the single component we want to keep is the *essential* H0 class, which
        # never dies and therefore produces no finite pair in either backend.  Every finite
        # H0 pair is consequently a spurious component already, and none must be excluded --
        # excluding the most persistent one here would let the largest satellite survive.
        terms = []
        for pairs in (h0, h1):
            if not pairs:
                continue
            pairs = sorted(
                pairs, key=lambda p: -abs(img.ravel()[p[0]] - img.ravel()[p[1]])
            )[:max_pairs]
            idx = torch.as_tensor(pairs, device=prob.device, dtype=torch.long)
            births = flat[i].gather(0, idx[:, 0])
            deaths = flat[i].gather(0, idx[:, 1])
            terms.append(((births - deaths) ** 2).sum())
        if terms:
            total = total + torch.stack(terms).sum()
    return total / max(b, 1)


def persistence_diagram(prob: np.ndarray, max_points: int = 32) -> np.ndarray:
    """(N, 3) array of (birth, death, homology_dim) for the PersLay descriptor."""
    h0, h1 = persistence_pairs(prob)
    flat = prob.ravel()
    pts = [(float(flat[b]), float(flat[d]), 0.0) for b, d in h0]
    pts += [(float(flat[b]), float(flat[d]), 1.0) for b, d in h1]
    if not pts:
        return np.zeros((0, 3), dtype=np.float32)
    pts.sort(key=lambda p: -abs(p[0] - p[1]))
    return np.asarray(pts[:max_points], dtype=np.float32)
