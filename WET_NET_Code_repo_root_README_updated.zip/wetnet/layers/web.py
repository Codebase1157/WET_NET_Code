"""Wavelet-Evidential Bridge (WEB) and the fusion-rule ablation of Table VI.

Reviewer #1, major comment 7, asked for an ablation isolating the evidential mechanism from a
simpler gating baseline.  ``fusion=`` selects one of four rules operating on exactly the same
DTCWT decomposition, so the only thing that varies between rows of Table VI is how the four
band groups are combined:

  ``uniform``      w_b = 1/4, no weighting at all.
  ``static``       four free scalars through a softmax -- learned but input-independent.
  ``se``           squeeze-and-excitation gate predicting the weights from globally pooled
                   band descriptors: content-adaptive, but not evidential.
  ``evidential``   Dirichlet evidence per band, combined by subjective logic (the proposal).

Only ``evidential`` yields a distribution over the band evidence, so only it can emit the
pixel-level uncertainty map of Fig. 11.  The other three return ``None`` for the uncertainty,
which is the point the revised Section IV-E4 makes.

The softplus activation on the evidence head (Reviewer #4, comment 5) is
``softplus(x) = ln(1 + e^x)``, derivative the logistic sigmoid.  Non-negativity is required
because the Dirichlet concentrations are ``alpha_b = e_b + 1`` and a negative ``e_b`` would
push ``alpha_b`` below one.  ReLU would also give non-negativity but maps the whole negative
half-line to exactly zero with zero derivative, so a band provisionally judged uninformative
would receive no gradient and could never recover.  Softplus is strictly positive with an
everywhere-positive derivative, so a suppressed band keeps a path back into the fusion.
"""

from __future__ import annotations

from typing import Optional, Tuple

import torch
import torch.nn as nn

from .dtcwt import BAND_NAMES, DualTreeDWT2D

FUSIONS = ("uniform", "static", "se", "evidential")


class EvidentialHead(nn.Module):
    """1x1 convolution + softplus -> strictly positive Dirichlet evidence for one band group.

    ``eps`` is not cosmetic.  ``ln(1 + e^x)`` underflows to *exactly* zero in float32 below
    roughly x = -104, which would make ``alpha = e + 1`` equal 1 and reintroduce precisely the
    dead-band failure mode that motivated choosing softplus over ReLU.  Batch normalisation
    upstream keeps inputs far from that regime, but the floor makes the Dirichlet valid by
    construction rather than by luck.  Note the gradient, ``sigmoid(x)``, stays strictly
    positive down to about x = -88 in float32 -- compared with ReLU, whose gradient is zero
    for *every* negative input, that is the whole operating range and then some.
    """

    def __init__(self, ch: int, num_classes: int = 2, eps: float = 1e-8):
        super().__init__()
        self.conv = nn.Conv2d(ch, num_classes, kernel_size=1, bias=True)
        self.act = nn.Softplus()
        self.eps = float(eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.conv(x)).clamp_min(self.eps)   # (B, K, h, w), strictly positive


class WEB(nn.Module):
    """Decompose -> weight -> reconstruct -> refine.

    Returns ``(f_bridge, uncertainty, alphas, weights)``.  ``uncertainty`` is ``None`` for
    every non-evidential fusion rule; ``alphas`` is ``None`` likewise and is what the
    evidential calibration loss consumes.
    """

    def __init__(self, ch: int, levels: int = 2, fusion: str = "evidential",
                 num_classes: int = 2, n_stages: int = 5, wavelet: str = "db5"):
        super().__init__()
        if fusion not in FUSIONS:
            raise ValueError(f"fusion must be one of {FUSIONS}, got {fusion!r}")
        self.fusion = fusion
        self.num_classes = num_classes
        self.dtcwt = DualTreeDWT2D(levels=levels, n_stages=n_stages, wavelet=wavelet)

        if fusion == "evidential":
            self.heads = nn.ModuleList([EvidentialHead(ch, num_classes) for _ in BAND_NAMES])
        elif fusion == "static":
            self.logits = nn.Parameter(torch.zeros(len(BAND_NAMES)))
        elif fusion == "se":
            hidden = max(4, ch // 4)
            self.se = nn.Sequential(
                nn.Linear(ch * len(BAND_NAMES), hidden), nn.GELU(),
                nn.Linear(hidden, len(BAND_NAMES)),
            )

        self.refine = nn.Sequential(
            nn.Conv2d(ch, ch, kernel_size=1, bias=False), nn.BatchNorm2d(ch), nn.GELU()
        )

    # ----------------------------------------------------------------------------------
    def _weights(self, feats) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[torch.Tensor]]:
        ref = feats["ll"]
        b = ref.shape[0]
        if self.fusion == "uniform":
            w = torch.full((b, len(BAND_NAMES)), 1.0 / len(BAND_NAMES),
                           device=ref.device, dtype=ref.dtype)
            return w, None, None
        if self.fusion == "static":
            return torch.softmax(self.logits, 0).expand(b, -1), None, None
        if self.fusion == "se":
            desc = torch.cat([feats[n].mean(dim=(-2, -1)) for n in BAND_NAMES], dim=1)
            return torch.softmax(self.se(desc), dim=1), None, None

        # -- evidential: Dirichlet evidence -> subjective-logic reliability ------------
        alphas, rels = [], []
        for head, name in zip(self.heads, BAND_NAMES):
            evidence = head(feats[name])                       # (B, K, h, w)
            alpha = evidence + 1.0
            strength = alpha.sum(dim=1, keepdim=True)          # S_b
            u = self.num_classes / strength                    # (B, 1, h, w), in (0, 1]
            alphas.append(alpha)
            rels.append((1.0 - u).mean(dim=(1, 2, 3)))         # r_b = 1 - u_b
        rel = torch.stack(rels, dim=1).clamp_min(1e-6)         # (B, 4)
        w = rel / rel.sum(dim=1, keepdim=True)                 # subjective-logic weights

        # pixel-level uncertainty: reliability-weighted mixture of the band Dirichlets
        alpha_fused = sum(w[:, i].view(-1, 1, 1, 1) * a for i, a in enumerate(alphas))
        unc = self.num_classes / alpha_fused.sum(dim=1, keepdim=True)
        return w, torch.stack(alphas, dim=1), unc

    # ----------------------------------------------------------------------------------
    def forward(self, f4: torch.Tensor):
        pyr_a, pyr_b = self.dtcwt(f4)
        feats = DualTreeDWT2D.band_features(pyr_a, pyr_b)
        w, alphas, unc = self._weights(feats)
        qa, qb = DualTreeDWT2D.apply_weights(pyr_a, pyr_b, w)
        recon = self.dtcwt.inverse(qa, qb)
        return self.refine(recon), unc, alphas, w


# --------------------------------------------------------------------------------------
# Bridge baselines for the Table V ablation
# --------------------------------------------------------------------------------------
class ASPP(nn.Module):
    def __init__(self, ch: int, rates=(1, 6, 12)):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Sequential(nn.Conv2d(ch, ch // 2, 3, padding=r, dilation=r, bias=False),
                          nn.BatchNorm2d(ch // 2), nn.GELU()) for r in rates
        ])
        self.proj = nn.Sequential(nn.Conv2d((ch // 2) * len(rates), ch, 1, bias=False),
                                  nn.BatchNorm2d(ch), nn.GELU())

    def forward(self, x):
        return self.proj(torch.cat([b(x) for b in self.branches], 1)), None, None, None


class SPP(nn.Module):
    def __init__(self, ch: int, sizes=(1, 2, 4)):
        super().__init__()
        self.sizes = sizes
        self.proj = nn.Sequential(nn.Conv2d(ch * (len(sizes) + 1), ch, 1, bias=False),
                                  nn.BatchNorm2d(ch), nn.GELU())

    def forward(self, x):
        import torch.nn.functional as F
        outs = [x] + [F.interpolate(F.adaptive_avg_pool2d(x, s), size=x.shape[-2:],
                                    mode="bilinear", align_corners=False) for s in self.sizes]
        return self.proj(torch.cat(outs, 1)), None, None, None


class PDCP(nn.Module):
    """Parallel dilated-convolution pyramid, the bridge of DFF-UNet, rates (1, 3, 5)."""

    def __init__(self, ch: int, rates=(1, 3, 5)):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Sequential(nn.Conv2d(ch, ch // 3, 3, padding=r, dilation=r, groups=1, bias=False),
                          nn.BatchNorm2d(ch // 3), nn.GELU()) for r in rates
        ])
        self.proj = nn.Sequential(nn.Conv2d((ch // 3) * len(rates), ch, 1, bias=False),
                                  nn.BatchNorm2d(ch), nn.GELU())

    def forward(self, x):
        return self.proj(torch.cat([b(x) for b in self.branches], 1)), None, None, None


def build_bridge(name: str, ch: int, **kw):
    name = name.lower()
    if name == "web":
        return WEB(ch, **kw)
    if name == "aspp":
        return ASPP(ch)
    if name == "spp":
        return SPP(ch)
    if name == "pdcp":
        return PDCP(ch)
    if name == "doubleconv":
        return nn.Sequential(nn.Conv2d(ch, ch, 3, padding=1, bias=False), nn.BatchNorm2d(ch),
                             nn.GELU(), nn.Conv2d(ch, ch, 3, padding=1, bias=False),
                             nn.BatchNorm2d(ch), nn.GELU())
    raise ValueError(f"unknown bridge {name!r}")
