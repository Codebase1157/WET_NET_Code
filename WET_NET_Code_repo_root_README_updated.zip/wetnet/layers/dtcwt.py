"""Learnable dual-tree complex wavelet transform with an exact perfect-reconstruction guarantee.

Reviewer #1 (major comments 5 and 7) objected, correctly, that the manuscript's claim of an
"exact-reconstruction guarantee" for the WEB module is inconsistent with re-weighting the
sub-bands before inversion.  The revised manuscript makes two weaker but provable claims
instead, and this module is written so that both are true *by construction* and testable:

  (P1) losslessness   iDTCWT(DTCWT(F)) == F exactly, for any parameter values.
  (P2) identity       uniform band weights give iDTCWT(D_w DTCWT(F)) == w * F exactly,
                      so the identity map (up to a scalar the following 1x1 conv absorbs)
                      lies inside the hypothesis space of the bridge.

Both are asserted in tests/test_dtcwt.py and tests/test_web.py.

The guarantee is obtained by parameterising each analysis filter bank as a *paraunitary
lattice*: a cascade of Givens rotations interleaved with unit delays, operating on the two
polyphase components.  Every stage is an orthogonal (hence exactly invertible) map, so the
composite transform is orthonormal for ANY value of the learnable angles -- perfect
reconstruction cannot be lost during training.  Boundary handling is periodic, which keeps
the delay stage invertible as well.

Kingsbury's q-shift filters are themselves orthonormal, so this parameterisation is a
faithful learnable generalisation of them.  ``fit_lattice_angles`` recovers the angles of
any orthonormal FIR filter by least squares, and is used to initialise both trees from real
wavelet filters (Daubechies by default; pass the q-shift coefficients to reproduce the
manuscript exactly).
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn


# --------------------------------------------------------------------------------------
# 1-D paraunitary lattice
# --------------------------------------------------------------------------------------
def _polyphase(x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Split the last axis into even/odd polyphase components."""
    return x[..., 0::2], x[..., 1::2]


def _interleave(even: torch.Tensor, odd: torch.Tensor) -> torch.Tensor:
    out = torch.stack((even, odd), dim=-1)
    return out.reshape(*even.shape[:-1], 2 * even.shape[-1])


class OrthLattice1D(nn.Module):
    """Orthonormal two-channel FIR analysis/synthesis bank of filter length ``2 * n_stages``.

    Parameters
    ----------
    n_stages:
        Number of lattice stages ``K``.  The equivalent FIR filters have length ``2K``;
        ``K = 5`` gives length-10 filters, matching the manuscript's q-shift length.
    """

    def __init__(self, n_stages: int = 5, init_angles: Sequence[float] | None = None):
        super().__init__()
        self.n_stages = int(n_stages)
        if init_angles is None:
            init_angles = [math.pi / 4] * self.n_stages
        angles = torch.as_tensor(list(init_angles), dtype=torch.float32)
        if angles.numel() != self.n_stages:
            raise ValueError(f"expected {self.n_stages} angles, got {angles.numel()}")
        self.theta = nn.Parameter(angles)

    # -- analysis ----------------------------------------------------------------------
    def analysis(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """``x`` has shape (..., L) with L even.  Returns (low, high), each (..., L//2)."""
        if x.shape[-1] % 2:
            raise ValueError("signal length must be even")
        a, b = _polyphase(x)
        c, s = torch.cos(self.theta), torch.sin(self.theta)
        for k in range(self.n_stages):
            if k > 0:                                  # unit delay, periodic => invertible
                b = torch.roll(b, shifts=1, dims=-1)
            a, b = c[k] * a - s[k] * b, s[k] * a + c[k] * b
        return a, b

    # -- synthesis ---------------------------------------------------------------------
    def synthesis(self, low: torch.Tensor, high: torch.Tensor) -> torch.Tensor:
        a, b = low, high
        c, s = torch.cos(self.theta), torch.sin(self.theta)
        for k in range(self.n_stages - 1, -1, -1):
            a, b = c[k] * a + s[k] * b, -s[k] * a + c[k] * b
            if k > 0:
                b = torch.roll(b, shifts=-1, dims=-1)
        return _interleave(a, b)

    # -- cost accounting ---------------------------------------------------------------
    def macs_for(self, n_samples: int) -> int:
        """Multiply-accumulates for an analysis (or synthesis) pass over ``n_samples``.

        Each lattice stage applies a Givens rotation to ``n_samples / 2`` polyphase pairs,
        i.e. four multiplies per pair.  The transform is implemented with tensor algebra
        rather than nn.Conv2d, so it is invisible to a conv-only FLOP counter -- this method
        exists so that ``wetnet.complexity`` can account for it explicitly.
        """
        return int(self.n_stages * (n_samples // 2) * 4)

    # -- the equivalent FIR filters, for inspection/plotting ---------------------------
    def filters(self) -> Tuple[torch.Tensor, torch.Tensor]:
        """Equivalent low-pass and high-pass analysis FIR filters.

        ``h[k]`` is the response of output sample 0 to an impulse at input position ``k``,
        which is the definition of the analysis filter for a decimating bank.
        """
        n = 4 * self.n_stages
        imp = torch.eye(n, device=self.theta.device, dtype=self.theta.dtype)
        lo, hi = self.analysis(imp)
        return lo[:, 0], hi[:, 0]

    @torch.no_grad()
    def impulse_response(self) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.filters()


def fit_lattice_angles(dec_lo: Sequence[float], n_stages: int, iters: int = 4000,
                       lr: float = 0.05, seed: int = 0) -> List[float]:
    """Least-squares fit of lattice angles to a target orthonormal low-pass filter.

    Used to initialise the trees from real wavelet coefficients.  Pass Kingsbury's q-shift
    coefficients here to reproduce the manuscript's stated initialisation exactly.
    """
    torch.manual_seed(seed)
    target = torch.as_tensor(list(dec_lo), dtype=torch.float32)
    n = 4 * n_stages
    pad = torch.zeros(n)
    pad[: target.numel()] = target
    best, best_loss = None, float("inf")
    for trial in range(6):                       # the fit is non-convex; restart a few times
        torch.manual_seed(seed + trial)
        lat = OrthLattice1D(n_stages, init_angles=(torch.rand(n_stages) * math.pi).tolist())
        opt = torch.optim.Adam(lat.parameters(), lr=lr)
        for _ in range(iters):
            opt.zero_grad()
            lo, _ = lat.filters()
            # the lattice fixes the filter only up to a circular shift and a sign
            cand = torch.stack([torch.roll(lo, s) for s in range(n)])
            loss = torch.minimum(((cand - pad) ** 2).sum(-1), ((cand + pad) ** 2).sum(-1)).min()
            loss.backward()
            opt.step()
        val = float(loss.detach())
        if val < best_loss:
            best_loss, best = val, [float(v) for v in lat.theta.detach()]
    return best


# Pre-fitted lattice angles, so importing this module costs nothing.  The residual is the
# squared error against the target orthonormal filter; the db2 fit is exact (its angles are
# the classical -pi/6, -pi/12 pair), while the longer filters land in a local minimum of a
# non-convex fit.  This only affects the *initialisation*: the angles are learnable and
# perfect reconstruction holds for any value, so a small fit residual is harmless.
_ANGLE_TABLE: Dict[str, List[float]] = {
    "db2:2": [-0.523599, -0.261799],                                    # residual 3.6e-15
    "db5:5": [2.487620, 1.120443, -0.943174, 1.845656, 0.963452],       # residual 2.5e-03
    "db7:7": [2.681206, 2.646129, -0.407547, -0.032188,
              1.598652, 3.040770, 2.225697],                            # residual 2.3e-04
}


def _default_angles(n_stages: int, wavelet: str, cache: Dict[str, List[float]] = {}) -> List[float]:
    key = f"{wavelet}:{n_stages}"
    if key in _ANGLE_TABLE:
        return list(_ANGLE_TABLE[key])
    if key not in cache:
        try:
            import pywt

            dec_lo = pywt.Wavelet(wavelet).dec_lo
        except Exception:                                   # pragma: no cover - optional dep
            dec_lo = [1 / math.sqrt(2), 1 / math.sqrt(2)]
        cache[key] = fit_lattice_angles(dec_lo, n_stages)
    return cache[key]


# --------------------------------------------------------------------------------------
# separable 2-D transform (one tree)
# --------------------------------------------------------------------------------------
class SeparableDWT2D(nn.Module):
    """One orthonormal separable 2-D wavelet tree built from two 1-D lattices."""

    def __init__(self, n_stages: int = 5, wavelet: str = "db5", jitter: float = 0.0,
                 seed: int = 0):
        super().__init__()
        base = _default_angles(n_stages, wavelet)
        g = torch.Generator().manual_seed(seed)
        off = (torch.rand(n_stages, generator=g) - 0.5) * 2 * jitter
        self.row = OrthLattice1D(n_stages, [b + float(o) for b, o in zip(base, off)])
        self.col = OrthLattice1D(n_stages, [b - float(o) for b, o in zip(base, off)])

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """x: (B, C, H, W).  Returns LL/LH/HL/HH each (B, C, ceil(H/2), ceil(W/2)).

        Odd side lengths are replicate-padded to even and the pad is removed again by
        ``inverse``, so perfect reconstruction still holds exactly for any input size.
        """
        h, w = x.shape[-2:]
        pad_w, pad_h = w % 2, h % 2
        if pad_w or pad_h:
            x = torch.nn.functional.pad(x, (0, pad_w, 0, pad_h), mode="replicate")
        lo_w, hi_w = self.row.analysis(x)                       # split along width
        lo_w = lo_w.transpose(-1, -2)
        hi_w = hi_w.transpose(-1, -2)
        ll, hl = self.col.analysis(lo_w)                        # split along height
        lh, hh = self.col.analysis(hi_w)
        return {
            "ll": ll.transpose(-1, -2),
            "hl": hl.transpose(-1, -2),
            "lh": lh.transpose(-1, -2),
            "hh": hh.transpose(-1, -2),
            "_shape": (h, w),
        }

    def inverse(self, bands: Dict[str, torch.Tensor]) -> torch.Tensor:
        ll = bands["ll"].transpose(-1, -2)
        hl = bands["hl"].transpose(-1, -2)
        lh = bands["lh"].transpose(-1, -2)
        hh = bands["hh"].transpose(-1, -2)
        lo_w = self.col.synthesis(ll, hl).transpose(-1, -2)
        hi_w = self.col.synthesis(lh, hh).transpose(-1, -2)
        out = self.row.synthesis(lo_w, hi_w)
        shape = bands.get("_shape")
        if shape is not None:
            out = out[..., : shape[0], : shape[1]]
        return out


# --------------------------------------------------------------------------------------
# dual tree, multi-level
# --------------------------------------------------------------------------------------
BAND_NAMES = ("ll", "lh", "hl", "hh")


class DualTreeDWT2D(nn.Module):
    """Learnable dual-tree transform, ``levels`` deep, with exact reconstruction.

    Two orthonormal trees are run in parallel (the dual-tree construction that buys
    approximate shift invariance and directional selectivity).  Reconstruction averages the
    two trees' independent inverses; since each is exact, the average is exact -- this is
    what makes property (P1) hold for any parameter values.

    Redundancy is 4x in two dimensions, which is the figure quoted in Section II-C of the
    revised manuscript.
    """

    def __init__(self, levels: int = 2, n_stages: int = 5, wavelet: str = "db5"):
        super().__init__()
        self.levels = int(levels)
        self.tree_a = SeparableDWT2D(n_stages, wavelet, jitter=0.00, seed=0)
        self.tree_b = SeparableDWT2D(n_stages, wavelet, jitter=0.15, seed=1)

    # -- one tree, multi-level ---------------------------------------------------------
    @staticmethod
    def _decompose(tree: SeparableDWT2D, x: torch.Tensor, levels: int) -> List[Dict[str, torch.Tensor]]:
        out, cur = [], x
        for _ in range(levels):
            bands = tree(cur)
            out.append(bands)
            cur = bands["ll"]
        return out

    @staticmethod
    def _reconstruct(tree: SeparableDWT2D, pyr: List[Dict[str, torch.Tensor]]) -> torch.Tensor:
        cur = pyr[-1]["ll"]
        for bands in reversed(pyr):
            cur = tree.inverse({**bands, "ll": cur})
        return cur

    # -- public API --------------------------------------------------------------------
    def forward(self, x: torch.Tensor):
        return (self._decompose(self.tree_a, x, self.levels),
                self._decompose(self.tree_b, x, self.levels))

    def inverse(self, pyr_a, pyr_b) -> torch.Tensor:
        return 0.5 * (self._reconstruct(self.tree_a, pyr_a) + self._reconstruct(self.tree_b, pyr_b))

    # -- cost accounting ---------------------------------------------------------------
    def macs_for(self, numel: int) -> int:
        """MACs for a full analysis + synthesis pass over a tensor with ``numel`` elements.

        Per tree and per level the separable transform makes one pass along rows and one
        along columns, each touching every sample; the next level sees a quarter of the
        samples.  Analysis and synthesis cost the same, and there are two trees.
        """
        total = 0
        for tree in (self.tree_a, self.tree_b):
            n = numel
            for _ in range(self.levels):
                total += 2 * (tree.row.macs_for(n) + tree.col.macs_for(n))   # analysis+synthesis
                n //= 4
        return total

    # -- band-group pooling, used by the evidential heads ------------------------------
    @staticmethod
    def band_features(pyr_a, pyr_b) -> Dict[str, torch.Tensor]:
        """One representative map per band group, at the finest level, for the evidence heads.

        The four groups are the low-pass band and the three directional high-pass groups,
        i.e. the "four directionally selective sub-bands" of the manuscript.  The two trees
        are combined as (a + b) / sqrt(2), the standard dual-tree combination.
        """
        feats = {}
        for name in BAND_NAMES:
            a, b = pyr_a[0][name], pyr_b[0][name]
            feats[name] = (a + b) / math.sqrt(2.0)
        return feats

    @staticmethod
    def apply_weights(pyr_a, pyr_b, weights: torch.Tensor):
        """Scale every band group by its weight, at every level.  ``weights``: (B, 4).

        This is the diagonal operator D_w of the revised Section III-C.  It is invertible
        whenever every weight is strictly positive, which softmax guarantees.
        """
        out = []
        for pyr in (pyr_a, pyr_b):
            new_pyr = []
            for lvl, bands in enumerate(pyr):
                nb = {k: v for k, v in bands.items() if k not in BAND_NAMES}
                for bi, name in enumerate(BAND_NAMES):
                    w = weights[:, bi].view(-1, 1, 1, 1)
                    if name == "ll" and lvl != len(pyr) - 1:
                        nb[name] = bands[name]      # interior LL is re-decomposed, not a leaf
                    else:
                        nb[name] = bands[name] * w
                new_pyr.append(nb)
            out.append(new_pyr)
        return out[0], out[1]
