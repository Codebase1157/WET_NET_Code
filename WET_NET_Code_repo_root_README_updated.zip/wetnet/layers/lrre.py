"""Lightweight Residual Refinement Encoder (LRRE) and the mirrored decoder.

Design choices here answer Reviewer #4, comments 3 and 4, and Reviewer #3's request that the
parameter-counting convention be unambiguous.

The 1x1 convolution appears in two distinct roles:

  * ``pw`` -- the pointwise stage of the depthwise-separable factorisation.  A depthwise
    convolution applies one kernel per channel and never mixes channels, so without this the
    C feature maps stay mutually independent.  Cost is ``C_in * C_out`` against the
    ``9 * C_in * C_out`` of a full 3x3 convolution; the pair costs ``9*C_in + C_in*C_out``,
    a ratio of ``1/C_out + 1/9`` (about 8.2x cheaper at C_out = 96).
  * ``shortcut`` -- a projection reconciling C_in with C_out so the residual addition is
    shape-compatible.  Preferred to zero-padding the channel axis because a learned
    projection can also rescale the identity path against the residual branch.

Stride is 1 for *every* convolution (padding 1 for the 3x3 depthwise kernel, 0 for the 1x1
kernels).  All spatial reduction is delegated to the 2x2 max-pool of stride 2 between
blocks.  Decoupling the two keeps input and output resolution equal inside a block, so the
residual addition needs no resampling, and it avoids strided convolution, which subsamples
the convolution output directly and aliases content above the new Nyquist limit.  That
matters specifically here: the shift-invariance and directional-selectivity properties that
justify the DTCWT are properties of the signal arriving at the bridge, so an encoder that had
already aliased its high frequencies would leave WEB reasoning about corrupted sub-bands.

The activation is GELU, ``x * Phi(x) = 0.5 * x * (1 + erf(x / sqrt(2)))``.  It is smooth
everywhere, unlike ReLU, whose derivative is identically zero on the negative half-line;
because the topological loss differentiates through a filtration of the predicted
probability map, a piecewise-constant derivative would create regions where those gradients
vanish.  GELU is also non-monotone for small negative inputs, retaining a bounded negative
response that preserves the weak boundary evidence low-contrast lesions provide.
"""

from __future__ import annotations

from typing import List, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class LRREBlock(nn.Module):
    """Depthwise 3x3 -> pointwise 1x1 -> 1x1-projection residual."""

    def __init__(self, c_in: int, c_out: int):
        super().__init__()
        self.dw = nn.Conv2d(c_in, c_in, kernel_size=3, stride=1, padding=1,
                            groups=c_in, bias=False)
        self.bn1 = nn.BatchNorm2d(c_in)
        self.pw = nn.Conv2d(c_in, c_out, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn2 = nn.BatchNorm2d(c_out)
        self.shortcut = nn.Conv2d(c_in, c_out, kernel_size=1, stride=1, bias=False)
        self.bn_s = nn.BatchNorm2d(c_out)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.act(self.bn1(self.dw(x)))          # (1) spatial context, no channel mixing
        y = self.bn2(self.pw(y))                    # (2) cross-channel mixing
        return self.act(y + self.bn_s(self.shortcut(x)))   # (3) projected residual


class LRREEncoder(nn.Module):
    """Four LRRE blocks separated by 2x2 max-pooling of stride 2.

    With a 256x256 input and the manuscript's widths (16, 32, 64, 96) the pyramid is
    F1 (16, 128, 128), F2 (32, 64, 64), F3 (64, 32, 32), F4 (96, 16, 16).
    """

    def __init__(self, in_ch: int = 3, widths: Sequence[int] = (16, 32, 64, 96),
                 blocks_per_stage: int = 1):
        super().__init__()
        self.widths = list(widths)
        self.blocks_per_stage = int(blocks_per_stage)
        chans = [in_ch] + self.widths
        stages = []
        for i in range(len(self.widths)):
            seq = [LRREBlock(chans[i], chans[i + 1])]
            seq += [LRREBlock(chans[i + 1], chans[i + 1])
                    for _ in range(self.blocks_per_stage - 1)]
            stages.append(nn.Sequential(*seq))
        self.blocks = nn.ModuleList(stages)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        feats = []
        for blk in self.blocks:
            x = self.pool(blk(x))
            feats.append(x)
        return feats                                 # [F1, F2, F3, F4]


class LRREDecoder(nn.Module):
    """Mirror of the encoder: bilinear upsample, skip concat, LRRE block.

    Bilinear upsampling rather than transposed convolution: it adds no parameters and
    produces no checkerboard artefacts, which would be indistinguishable from precisely the
    spurious high-frequency content the WEB module exists to suppress.
    """

    def __init__(self, widths: Sequence[int] = (16, 32, 64, 96), out_ch: int = 16,
                 blocks_per_stage: int = 1):
        super().__init__()
        w = list(widths)
        self.stages = nn.ModuleList()
        cur = w[-1]
        for i in range(len(w) - 2, -1, -1):
            seq = [LRREBlock(cur + w[i], w[i])]
            seq += [LRREBlock(w[i], w[i]) for _ in range(blocks_per_stage - 1)]
            self.stages.append(nn.Sequential(*seq))
            cur = w[i]
        self.out_ch = cur
        self.head = LRREBlock(cur, out_ch)

    def forward(self, bridge: torch.Tensor, feats: List[torch.Tensor]) -> torch.Tensor:
        x = bridge
        for i, stage in enumerate(self.stages):
            skip = feats[len(feats) - 2 - i]
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
            x = stage(torch.cat([x, skip], dim=1))
        return self.head(x)


# --------------------------------------------------------------------------------------
# Baseline encoders used by the Table III ablation (Reviewer #3)
# --------------------------------------------------------------------------------------
def build_encoder(name: str, in_ch: int = 3, widths: Sequence[int] = (16, 32, 64, 96),
                  blocks_per_stage: int = 1):
    """Return ``(encoder_module, out_widths)`` for one of the ablation encoders.

    Every encoder returns a four-level pyramid at strides 2, 4, 8, 16, so the bridge,
    decoder and TAR module downstream are *identical* across rows of Table III.  That is
    what makes the whole-network parameter counts in that table a like-for-like comparison,
    the point Reviewer #3 asked us to make explicit.
    """
    name = name.lower()
    if name == "lrre":
        enc = LRREEncoder(in_ch, widths, blocks_per_stage)
        return enc, list(widths)
    if name in {"resnet18", "resnet34", "mobilenetv3_small"}:
        return _TorchvisionEncoder(name, in_ch), _TorchvisionEncoder.WIDTHS[name]
    raise ValueError(f"unknown encoder {name!r}")


class _TorchvisionEncoder(nn.Module):
    """Thin wrapper exposing a torchvision backbone as a four-level pyramid."""

    WIDTHS = {
        "resnet18": [64, 128, 256, 512],
        "resnet34": [64, 128, 256, 512],
        "mobilenetv3_small": [16, 24, 48, 576],
    }

    def __init__(self, name: str, in_ch: int = 3):
        super().__init__()
        import torchvision.models as tvm

        self.name = name
        if name in {"resnet18", "resnet34"}:
            net = getattr(tvm, name)(weights=None)
            self.stem = nn.Sequential(net.conv1, net.bn1, net.relu)      # stride 2
            self.pool = net.maxpool
            self.l1, self.l2, self.l3, self.l4 = net.layer1, net.layer2, net.layer3, net.layer4
        else:
            net = tvm.mobilenet_v3_small(weights=None)
            f = net.features
            self.s1, self.s2, self.s3, self.s4 = f[:2], f[2:4], f[4:9], f[9:]

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        if self.name.startswith("resnet"):
            x = self.stem(x)                 # /2
            c1 = self.l1(self.pool(x))       # /4  -> treated as F1 after an extra pool
            c2 = self.l2(c1)                 # /8
            c3 = self.l3(c2)                 # /16
            c4 = self.l4(c3)                 # /32
            return [c1, c2, c3, c4]
        a = self.s1(x)
        b = self.s2(a)
        c = self.s3(b)
        d = self.s4(c)
        return [a, b, c, d]
