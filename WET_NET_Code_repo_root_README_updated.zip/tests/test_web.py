"""WEB bridge: fusion variants, softplus positivity, uncertainty availability."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest, torch
from wetnet.layers.web import FUSIONS, WEB


@pytest.mark.parametrize("fusion", FUSIONS)
def test_shape_and_weight_simplex(fusion):
    torch.manual_seed(0)
    web = WEB(8, levels=2, fusion=fusion)
    x = torch.randn(2, 8, 16, 16)
    out, unc, alphas, w = web(x)
    assert out.shape == x.shape
    assert torch.allclose(w.sum(1), torch.ones(2), atol=1e-5)
    assert (w > 0).all(), "softmax weights must be strictly positive for D_w to be invertible"


def test_only_evidential_emits_uncertainty():
    """The point of Table VI: a gate produces a weight, not a distribution."""
    x = torch.randn(1, 8, 16, 16)
    for f in FUSIONS:
        _, unc, alphas, _ = WEB(8, fusion=f)(x)
        if f == "evidential":
            assert unc is not None and alphas is not None
            assert (unc > 0).all() and (unc <= 1.0 + 1e-5).all()
        else:
            assert unc is None and alphas is None


def test_softplus_evidence_is_strictly_positive():
    """alpha = e + 1 must stay a valid Dirichlet concentration for every input, including
    inputs far enough negative that ln(1 + e^x) underflows in float32."""
    from wetnet.layers.web import EvidentialHead
    head = EvidentialHead(4)
    for scale in (1e-3, 1.0, 1e3):
        e = head(torch.randn(2, 4, 8, 8) * scale)
        assert (e > 0).all(), "evidence must never be exactly zero"
        assert torch.isfinite(e).all()


def test_softplus_gradient_survives_the_whole_operating_range():
    """Documents the float32 limit quoted in EvidentialHead's docstring."""
    x = torch.linspace(-80.0, 10.0, 200, requires_grad=True)
    torch.nn.functional.softplus(x).sum().backward()
    assert (x.grad > 0).all()


def test_relu_would_freeze_a_band_but_softplus_does_not():
    """Documents why softplus, not ReLU (Reviewer #4, comment 5)."""
    x = torch.full((1, 1), -20.0, requires_grad=True)
    torch.nn.functional.softplus(x).backward()
    assert float(x.grad) > 0.0
    y = torch.full((1, 1), -20.0, requires_grad=True)
    torch.nn.functional.relu(y).backward()
    assert float(y.grad) == 0.0
