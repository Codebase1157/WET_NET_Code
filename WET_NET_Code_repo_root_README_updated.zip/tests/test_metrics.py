"""Metric definitions -- Reviewer #4, comment 6."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from wetnet.metrics import (dice_confusion, dice_set, expected_calibration_error,
                            hd95, iou_lesion, iou_macro)

rng = np.random.default_rng(0)


def test_dice_confusion_form_equals_set_form():
    """2Tp/(2Tp+Fp+Fn) == 2|A n B|/(|A|+|B|).  The manuscript's Eq. (17) is correct."""
    for _ in range(50):
        a = rng.random((32, 32)) > 0.5
        b = rng.random((32, 32)) > 0.6
        assert abs(dice_confusion(a, b) - dice_set(a, b)) < 1e-6


def test_dice_iou_identity():
    """Dice = 2 IoU / (1 + IoU) holds exactly per image."""
    for _ in range(50):
        a = rng.random((24, 24)) > 0.5
        b = rng.random((24, 24)) > 0.4
        i = iou_lesion(a, b)
        assert abs(dice_confusion(a, b) - 2 * i / (1 + i)) < 1e-6


def test_lesion_iou_differs_from_class_averaged_iou():
    """The quantity Table VIII calls mIoU is single-class IoU, not the macro average."""
    a = np.zeros((32, 32), bool); a[4:12, 4:12] = True
    b = np.zeros((32, 32), bool); b[6:14, 6:14] = True
    assert abs(iou_lesion(a, b) - iou_macro(a, b)) > 0.1


def test_perfect_and_disjoint_extremes():
    a = np.zeros((16, 16), bool); a[2:8, 2:8] = True
    assert abs(dice_confusion(a, a) - 1.0) < 1e-5
    assert abs(iou_lesion(a, a) - 1.0) < 1e-5
    b = np.zeros((16, 16), bool); b[10:14, 10:14] = True
    assert dice_confusion(a, b) < 1e-5


def test_hd95_zero_for_identical_masks():
    a = np.zeros((32, 32), bool); a[8:20, 8:20] = True
    assert hd95(a, a) == 0.0


def test_ece_is_zero_for_a_perfectly_calibrated_certain_predictor():
    t = (rng.random((64, 64)) > 0.5)
    p = t.astype(float) * 1.0 + (~t) * 0.0
    assert expected_calibration_error(p, t) < 1e-6
