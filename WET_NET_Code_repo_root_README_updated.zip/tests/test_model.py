"""End-to-end shapes, configurability and gradient flow."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest, torch
from wetnet import WETNet, WETNetConfig
from wetnet.losses import WETNetLoss


def test_forward_shapes():
    m = WETNet(WETNetConfig(tar_stride=4))
    out = m(torch.randn(1, 3, 128, 128))
    assert out["logits"].shape == (1, 1, 128, 128)
    assert out["uncertainty"].shape == (1, 1, 128, 128)


@pytest.mark.parametrize("bridge", ["web", "pdcp", "aspp", "spp", "doubleconv"])
def test_every_bridge_runs(bridge):
    m = WETNet(WETNetConfig(bridge=bridge, tar_stride=4))
    assert m(torch.randn(1, 3, 64, 64))["logits"].shape == (1, 1, 64, 64)


def test_loss_backward_reaches_every_module():
    torch.manual_seed(0)
    m = WETNet(WETNetConfig(tar_stride=4))
    crit = WETNetLoss()
    out = m(torch.randn(2, 3, 64, 64))
    crit(out, (torch.rand(2, 1, 64, 64) > 0.5).float())["loss"].backward()
    missing = [n for n, p in m.named_parameters() if p.grad is None]
    assert not missing, f"no gradient reached: {missing[:5]}"


def test_parameter_report_separates_encoder_from_total():
    """Reviewer #3: the two conventions must never be confusable again."""
    r = WETNet(WETNetConfig()).parameter_report()
    assert r["encoder_params"] < r["total_params"]
    assert r["total_params"] == (r["encoder_params"] + r["bridge_params"]
                                 + r["decoder_params"] + r["tar_params"])
