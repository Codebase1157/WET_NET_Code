"""Perfect reconstruction and invertibility -- the properties the revised Section III-C claims."""
import sys, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest, torch
from wetnet.layers.dtcwt import BAND_NAMES, DualTreeDWT2D, OrthLattice1D, SeparableDWT2D

TOL = 1e-5


@pytest.mark.parametrize("K", [2, 5, 7])
def test_lattice_is_orthonormal_and_invertible(K):
    torch.manual_seed(0)
    lat = OrthLattice1D(K)
    x = torch.randn(4, 64)
    lo, hi = lat.analysis(x)
    assert torch.allclose(lat.synthesis(lo, hi), x, atol=TOL)
    # orthonormality: analysis preserves energy
    assert abs(float((lo ** 2).sum() + (hi ** 2).sum() - (x ** 2).sum())) < 1e-3


def test_lattice_pr_holds_for_arbitrary_angles():
    """PR must survive training, i.e. hold for angles that are not a real wavelet."""
    torch.manual_seed(1)
    lat = OrthLattice1D(5, init_angles=(torch.rand(5) * 6.28).tolist())
    x = torch.randn(2, 32)
    lo, hi = lat.analysis(x)
    assert torch.allclose(lat.synthesis(lo, hi), x, atol=TOL)


def test_separable_2d_perfect_reconstruction():
    torch.manual_seed(0)
    t = SeparableDWT2D(5)
    x = torch.randn(2, 6, 32, 32)
    assert torch.allclose(t.inverse(t(x)), x, atol=TOL)


@pytest.mark.parametrize("levels", [1, 2, 3])
def test_dualtree_perfect_reconstruction(levels):
    """(P1): iDTCWT(DTCWT(F)) == F exactly."""
    torch.manual_seed(0)
    dt = DualTreeDWT2D(levels=levels)
    x = torch.randn(2, 8, 32, 32)
    assert torch.allclose(dt.inverse(*dt(x)), x, atol=TOL)


def test_uniform_weights_reproduce_the_identity():
    """(P2): uniform band weights give w * F, so the identity is representable."""
    torch.manual_seed(0)
    dt = DualTreeDWT2D(levels=2)
    x = torch.randn(3, 4, 16, 16)
    pa, pb = dt(x)
    w = torch.full((3, len(BAND_NAMES)), 0.25)
    out = dt.inverse(*dt.apply_weights(pa, pb, w))
    assert torch.allclose(out, 0.25 * x, atol=TOL)


def test_positive_weights_keep_the_map_invertible():
    """D_w is invertible for strictly positive weights: no sub-band is annihilated."""
    torch.manual_seed(0)
    dt = DualTreeDWT2D(levels=1)
    x = torch.randn(1, 4, 16, 16)
    pa, pb = dt(x)
    w = torch.tensor([[0.7, 0.1, 0.15, 0.05]])
    qa, qb = dt.apply_weights(pa, pb, w)
    inv = torch.tensor([[1 / 0.7, 1 / 0.1, 1 / 0.15, 1 / 0.05]])
    ra, rb = dt.apply_weights(qa, qb, inv)
    assert torch.allclose(dt.inverse(ra, rb), x, atol=1e-4)


def test_gradients_flow_to_the_angles():
    dt = DualTreeDWT2D(levels=2)
    x = torch.randn(1, 4, 16, 16)
    dt.inverse(*dt(x)).square().sum().backward()
    assert dt.tree_a.row.theta.grad is not None
