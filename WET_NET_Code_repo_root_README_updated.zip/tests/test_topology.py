"""Persistent homology and the topological loss."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np, torch
from wetnet.layers.persistence import persistence_pairs, topological_loss


def disc(s, cy, cx, r):
    y, x = np.mgrid[0:s, 0:s]
    return ((y - cy) ** 2 + (x - cx) ** 2 < r * r).astype(np.float64)


CLEAN = np.clip(disc(64, 32, 32, 15) * 0.9 + 0.05, 0, 1)
SATELLITE = np.clip(CLEAN + disc(64, 10, 10, 4) * 0.7, 0, 1)
ANNULUS = np.clip((disc(64, 32, 32, 18) - disc(64, 32, 32, 8)) * 0.9 + 0.05, 0, 1)


def test_single_component_has_no_finite_h0_pairs():
    h0, h1 = persistence_pairs(CLEAN)
    assert len(h0) == 0 and len(h1) == 0


def test_satellite_creates_one_h0_pair():
    h0, _ = persistence_pairs(SATELLITE)
    assert len(h0) == 1


def test_hole_creates_one_h1_pair():
    _, h1 = persistence_pairs(ANNULUS)
    assert len(h1) == 1


def test_loss_is_zero_only_for_correct_topology():
    z = topological_loss(torch.tensor(CLEAN, dtype=torch.float32)[None])
    s = topological_loss(torch.tensor(SATELLITE, dtype=torch.float32)[None])
    a = topological_loss(torch.tensor(ANNULUS, dtype=torch.float32)[None])
    assert float(z) == 0.0 and float(s) > 0 and float(a) > 0


def test_gradient_reaches_the_offending_pixels():
    t = torch.tensor(SATELLITE, dtype=torch.float32)[None].requires_grad_(True)
    topological_loss(t).backward()
    assert t.grad is not None and int((t.grad != 0).sum()) > 0
