# Splits

## File structure

```text
splits/
├── ham10000_test.txt
├── ham10000_train.txt
├── isic2017_test.txt
├── isic2017_train.txt
├── isic2018_test.txt
├── isic2018_train.txt
├── make_splits.py
├── ph2_test.txt
├── ph2_train.txt
└── verify_splits.py
```

Each `.txt` file contains image identifiers, one per line.

## Configuration

Dataset configurations in `configs/` reference the split files:

- `configs/isic2018.yaml` → `splits/isic2018_train.txt`, `splits/isic2018_test.txt`
- `configs/isic2017.yaml` → `splits/isic2017_train.txt`, `splits/isic2017_test.txt`
- `configs/ham10000.yaml` → `splits/ham10000_train.txt`, `splits/ham10000_test.txt`
- `configs/ph2.yaml` → `splits/ph2_train.txt`, `splits/ph2_test.txt`

Generate or verify split files with:

```bash
python splits/make_splits.py --help
python splits/verify_splits.py all
```
