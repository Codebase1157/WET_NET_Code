# Train / test splits

This folder contains the exact train/test partitions used for **every** experiment in
*WET-Net: A Wavelet-Evidential Topology-Aware Network for Robust and Lightweight Skin Lesion
Segmentation* (Tables III–XI). Each model in the paper, including every baseline, is trained and
evaluated on these partitions, so that the comparison is a single controlled protocol rather than
a set of per-paper splits.

The split is an **explicit index file**, not a shuffle seed: a run reads the list of image
identifiers from the file below and uses exactly those images. This makes a run *reproducible*
(the membership is fixed on disk) rather than merely *re-derivable*. See `wetnet/data.py`,
`SkinLesionDataset(..., index_file=...)`.

## Files

| Dataset   | Train index                | Test index                |
| --------- | -------------------------- | ------------------------- |
| ISIC2018  | `isic2018_train.txt`       | `isic2018_test.txt`       |
| ISIC2017  | `isic2017_train.txt`       | `isic2017_test.txt`       |
| HAM10000  | `ham10000_train.txt`       | `ham10000_test.txt`       |
| PH2       | `ph2_train.txt`            | `ph2_test.txt`            |

**Format.** One image identifier per line, UTF-8, Unix newlines, no header. An identifier is the
image file *stem* — the file name without its extension and without the mask suffix — e.g.
`ISIC_0012345` for ISIC2018/2017, a HAM10000 `image_id` such as `ISIC_0027419`, and a PH2 code
such as `IMD002`. The loader matches `<stem>.<ext>` in `images/` and the corresponding mask in
`masks/` (mask suffix `_segmentation` for the ISIC-style sets).

## How the partitions were generated (Section IV-A)

For each dataset the publicly released labelled images are pooled and divided **once** into a
training and a test partition in a **7:3 ratio** with a **fixed random seed of 42**. No test
image is used for training, hyper-parameter tuning or checkpoint selection; the final-epoch
checkpoint is evaluated.

| Dataset   | Pool (source)                                   | Train | Test | Stratification |
| --------- | ----------------------------------------------- | ----: | ---: | -------------- |
| ISIC2018  | 2 594 train + 100 val (Task 1 release) = 2 694  | 1 886 |  808 | Seeded random (diagnostic labels not consistently available for the full segmentation pool) |
| ISIC2017  | 2 000 train + 150 val = 2 150                   | 1 500 |  650 | Stratified by diagnostic category |
| HAM10000  | 10 015 images                                   | 7 010 | 3 005 | Stratified by diagnostic category, **split at lesion level** via `lesion_id` |
| PH2       | 200 images                                      |   140 |   60 | Stratified by diagnostic category |

Notes:

- **Seed.** The single global seed is **42**, applied to the split routine of `make_splits.py`.
- **ISIC2018** uses a seeded random (non-stratified) split, because diagnostic labels are not
  consistently available for the full segmentation pool.
- **HAM10000** contains several images of the same physical lesion. The partition is therefore
  made **at lesion level** using the `lesion_id` field, so that no lesion contributes images to
  both partitions. This is verified from the `lesion_id` metadata (see `verify_splits.py`).
- **ISIC2017 / PH2** are stratified by diagnostic category so that each category appears in the
  train and test partitions in roughly its pool proportion.

## Reusing the splits

Point the dataset config at these files (already the default in the shipped configs):

```yaml
train_index: splits/isic2018_train.txt
test_index:  splits/isic2018_test.txt
```

then

```bash
python scripts/train.py --config configs/isic2018.yaml
```

## Regenerating the splits

The partitions can be regenerated deterministically from a local copy of each dataset:

```bash
# ISIC2018 — seeded random split over the pooled image stems
python splits/make_splits.py isic2018 \
    --image-dir /path/to/isic2018/all/images

# ISIC2017 / PH2 — stratified by diagnostic category (needs a labels CSV)
python splits/make_splits.py isic2017 \
    --image-dir /path/to/isic2017/all/images \
    --labels-csv /path/to/isic2017/labels.csv

python splits/make_splits.py ph2 \
    --image-dir /path/to/ph2/all/images \
    --labels-csv /path/to/ph2/labels.csv

# HAM10000 — lesion-level, stratified by dx (needs HAM10000_metadata.csv)
python splits/make_splits.py ham10000 \
    --image-dir /path/to/ham10000/all/images \
    --metadata-csv /path/to/HAM10000_metadata.csv
```

Every mode uses seed 42 and `test_size = 0.30`. Run `python splits/make_splits.py --help` for
the CSV column options (defaults match the public releases: HAM10000 `image_id` / `lesion_id` /
`dx`; a generic `image,label` schema for the others).

> If you still have the original `.txt` files you trained on, **commit those** — they are the
> authoritative record of the reported numbers. The generator reproduces the *protocol*; use it
> only if the originals are lost, and verify the result against the counts above.

## Verifying a committed split

```bash
# counts, and train/test disjointness, for one dataset:
python splits/verify_splits.py isic2018

# HAM10000 additionally checks that no lesion_id appears in both partitions:
python splits/verify_splits.py ham10000 --metadata-csv /path/to/HAM10000_metadata.csv

# all four at once (count + overlap checks):
python splits/verify_splits.py all
```

The verifier exits non-zero if any check fails, so it can gate a commit or run in CI.
