# How to satisfy the reviewer's split-files requirement

**Repo:** https://github.com/Codebase1157/WET_NET_Code

## What was wrong

The manuscript's *Code and Data Availability* section (and your response letter) states that the
split files live at `splits/isic2018_train.txt`, `splits/isic2018_test.txt` (same pattern for
ISIC2017, HAM10000, PH2) and that `splits/README.md` records the seed and stratification.

The repository does **not** contain those files. There is no top-level `splits/` folder, and the
`configs/splits/` folder inside `WETNetcode.zip` is **empty**. There is also a path mismatch: the
manuscript says `splits/...` while the four `configs/*.yaml` point to `configs/splits/...`.

## What is in this package

```
splits/
  README.md          <- the file the manuscript says records seed + stratification
  make_splits.py     <- regenerates the partitions (seed 42, 7:3, per the paper)
  verify_splits.py   <- checks counts, train/test disjointness, HAM10000 lesion-level split
configs/             <- the four configs, patched to read from splits/ (was configs/splits/)
  isic2018.yaml  isic2017.yaml  ham10000.yaml  ph2.yaml
```

## Step 1 — add the actual split `.txt` files  (you must do this; I can't)

The eight `*_train.txt` / `*_test.txt` files list real image identifiers, so they can only come
from your data. Two options:

- **Preferred:** copy the exact split files you trained on into `splits/`. These are the
  authoritative record of the numbers in the paper.
- **Or regenerate** them from your local dataset copies:

  ```bash
  python splits/make_splits.py isic2018 --image-dir /path/to/isic2018/all/images
  python splits/make_splits.py isic2017 --image-dir /path/to/isic2017/all/images --labels-csv /path/to/isic2017/labels.csv
  python splits/make_splits.py ph2      --labels-csv /path/to/ph2/labels.csv
  python splits/make_splits.py ham10000 --metadata-csv /path/to/HAM10000_metadata.csv
  ```

## Step 2 — verify before committing

```bash
python splits/verify_splits.py all
python splits/verify_splits.py ham10000 --metadata-csv /path/to/HAM10000_metadata.csv
```

All checks must pass (exit code 0). Confirm the printed counts match the manuscript
(1886/808, 1500/650, 7010/3005, 140/60) — or, if they differ, decide which number is correct and
make the paper and the files agree.

## Step 3 — make the repo and manuscript agree on the path

Use the patched `configs/` in this package (they read `splits/...`). This matches the manuscript
wording. (If you would rather keep `configs/splits/`, then change the manuscript instead — but the
reviewer quoted `splits/...`, so moving the folder up is the smaller change.)

## Step 4 — commit and push

```bash
git add splits/ configs/
git commit -m "Add train/test split index files, generator, verifier, and splits/README (reviewer request)"
git push
```

## Also worth checking before resubmission (not required by this comment)

The repo's own `README.md` flags a **parameter-count discrepancy**: the architecture as described
measures ~0.074 M parameters, not the 0.312 M reported in the manuscript (the GFLOPs figure does
reproduce). A reviewer running the code will hit this immediately. Resolve it — reconcile the
architecture description with the reported budget, or correct the figure — before you resubmit.
